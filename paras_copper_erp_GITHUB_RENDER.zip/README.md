# 🏭 PARAS OVERSEAS JHULASAN — Copper & Scrap ERP (100% Python)

Complete Copper & Scrap Factory ERP built in **Python (FastAPI + SQLAlchemy)** — GitHub + **Render.com** Ready!

---

## ✨ Kya-Kya Shamil Hai (Full Copper System)

1. **🏠 Factory Entry & Live Stock (`/`)**
   - **5 Action Cards**: Naya/Purana Container, Daily Sorting (Photo + Manual), Local Stock, Sell/Dispatch (Photo + Manual), Material Return / Jobwork
   - **Premium Clean Live Stock Capsule** (iOS minimal black-white view, instant filter, WhatsApp share)
   - **Master Container Shorting Report** (Invoice NW, Kanta 1, Kanta 2, % Recovery, Output/Labor, Item Breakdown, Daily Sorting Logbook, Purana Archive Container support)
   - **Smart Parchi Reader**: 100-Key Auto-Rotation + Secondary Backup + **Automatic Total-Line Filter & Jambo/Weight Sum Calculator**
   - **Jyoti 3D Clean Assistant** (Voice Mic + Instant Copper Stock / Khata / Bhatti answers)
2. **👔 Seth Ji View-Only Portal (`/seth` + Secret WhatsApp Link)**
   - **100% Read-Only Mode**: Seth Ji mobile ya laptop par Live Stock, Container Shorting, Khata Book, Bhatti Loss, Dispatch, Gallery aur Analytics dekh sakte hain + Excel download kar sakte hain — **koi entry add/edit/delete nahi ho sakti!**
   - Admin Panel se **1-Click WhatsApp Secret Link** copy karke seedha Seth Ji ko bhej sakte hain.
3. **👑 Admin Control Panel (`/admin`)**
   - Seth Ji View-Only Link & PIN management
   - Users & Roles (`admin`, `operator` Munim, `seth` View-Only)
   - **100 Smart Reader Keys** bulk manager
   - Custom Copper & Scrap Categories manager
   - Full `.xlsx` Excel Export + `.json` Backup & Restore + System Audit Log
4. **📒 Khata Book (`/khata`)** — Excel-style ledger per Copper/Scrap item + Loose-to-Jambo pack helper + `.xlsx` export
5. **🔥 Copper Furnace / Bhatti (`/furnace`)** — Input → Output Copper Ladi/Ingot → Auto Burning Loss KG, Loss %, Recovery % + Live Stock auto-sync
6. **🚚 Vehicle Dispatch (`/dispatch`)** — Multi-item loading + Dharam Kanta & Party Wt match + Vehicle/RC/DL photos
7. **🏆 Container Quality (`/quality`)** — Auto Grade (`A+`, `A`, `B`, `C`, `D`) based on Copper yield %
8. **📦 Other Stock (`/other-stock`)**, **📸 Gallery (`/gallery`)**, **📜 Stock Ledger (`/ledger`)**, **📊 Analytics (`/analytics`)**, **📊 Reports (`/reports`)**

---

## 🚀 GitHub + Render.com Par Kaise Chalayein (Step-by-Step)

### Step 1: GitHub Par Upload Karein
1. [github.com](https://github.com) par login karein → **New Repository** banayein (e.g. `paras-copper-erp`).
2. Is ZIP ko apne laptop/phone par **extract** karein.
3. Saari files (`main.py`, `app/`, `templates/`, `static/`, `requirements.txt`, `render.yaml`, `Dockerfile`, `runtime.txt`) GitHub repo ke root me upload karke **Commit changes** dabayein.

### Step 2: Render.com Par Deploy Karein
1. [dashboard.render.com](https://dashboard.render.com) kholein → **New +** → **Web Service** chunein.
2. Apna GitHub repo (`paras-copper-erp`) connect karein.
3. Render settings:
   - **Runtime**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. **Environment Variables** me add karein (optional, default bhi kaam karega):
   - `PYTHON_VERSION` = `3.11.9`
   - `MASTER_CODE` = `8808`
   - `SETH_PIN` = `1111`
   - `DATABASE_URL` = *(Permanent cloud database ke liye Render PostgreSQL ya apna MySQL URL dalein, warna SQLite automatic chalega)*
5. **Create Web Service** par click karein — 2 minute me aapka Copper ERP Live ho jayega!

---

## 🔐 Default Access Details (Admin Panel se kabhi bhi badal sakte hain)
- **Factory Save/Edit Security Code**: Masked PIN (`8808` default)
- **👑 Admin Panel (`/admin` ya `/login`)**: Admin Master Code (`8808` default)
- **👔 Seth Ji View-Only (`/login` → Seth Ji Login)**: Default PIN `1111` *(ya Admin Panel se Direct WhatsApp Link bhejein!)*
