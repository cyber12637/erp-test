from datetime import datetime
from typing import List, Optional
from urllib.parse import quote
from fastapi import APIRouter, Request, Depends, Form, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Container, Transaction
from ..security import (
    get_current_actor, get_setting, check_write_permission,
    strip_security_code, log_audit
)
from ..services import (
    get_live_stock, get_container_report, ensure_category_saved,
    update_all_container_qualities
)
from ..vision_service import extract_parchi_from_image, answer_jyoti_query
from .auth_admin import base_ctx, templates, _redir

router = APIRouter()


def _parse_date(date_str: str) -> datetime:
    if date_str:
        try:
            d = datetime.strptime(date_str.strip(), "%Y-%m-%d")
            now = datetime.now()
            return d.replace(hour=now.hour, minute=now.minute, second=now.second)
        except Exception:
            pass
    return datetime.now()


@router.get("/", response_class=HTMLResponse)
async def home_page(
    request: Request,
    selected_container: str = "",
    db: Session = Depends(get_db),
):
    actor = get_current_actor(request, db)
    if get_setting(db, "require_login", "0") == "1" and not actor["logged_in"]:
        return _redir("/login")

    all_containers = db.query(Container).order_by(Container.id.desc()).all()
    open_containers = [c for c in all_containers if c.status == "OPEN"]

    if not selected_container:
        if open_containers:
            selected_container = open_containers[0].container_no
        elif all_containers:
            selected_container = all_containers[0].container_no

    stock = get_live_stock(db)
    c_report = get_container_report(db, selected_container) if selected_container else None

    local_txns = (
        db.query(Transaction)
        .filter(Transaction.txn_type == "LOCAL_IN")
        .order_by(Transaction.txn_date.desc(), Transaction.id.desc())
        .limit(40)
        .all()
    )
    local_total_kg = round(sum(float(t.weight_kg or 0) for t in local_txns), 2)

    recent_txns = (
        db.query(Transaction)
        .order_by(Transaction.txn_date.desc(), Transaction.id.desc())
        .limit(80)
        .all()
    )

    ctx = base_ctx(request, db, "home")
    ctx.update({
        "all_containers": all_containers,
        "open_containers": open_containers,
        "selected_container": selected_container,
        "stock": stock,
        "c_report": c_report,
        "local_txns": local_txns,
        "local_total_kg": local_total_kg,
        "recent_txns": recent_txns,
    })
    return templates.TemplateResponse(request, "index.html", ctx)


@router.post("/action/add-container")
async def action_add_container(
    request: Request,
    sec_key: str = Form(""),
    container_no: str = Form(...),
    invoice_nw: float = Form(...),
    kanta1_name: str = Form(""),
    kanta1_wt: float = Form(0.0),
    kanta2_name: str = Form(""),
    kanta2_wt: float = Form(0.0),
    archive_flag: Optional[str] = Form(None),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/", err=err)

    cno = container_no.strip().upper()
    if not cno or invoice_nw <= 0:
        return _redir("/", err="Container No aur Invoice NW (0 se zyada) zaroori hai!")

    if db.query(Container).filter(Container.container_no == cno).first():
        return _redir(f"/?selected_container={quote(cno)}", err=f"Container {cno} pehle se maujood hai!")

    is_arch = 1 if archive_flag else 0
    cont = Container(
        container_no=cno,
        invoice_nw=float(invoice_nw),
        status="OPEN",
        kanta1_name=kanta1_name.strip(),
        kanta1_wt=float(kanta1_wt or 0),
        kanta2_name=kanta2_name.strip(),
        kanta2_wt=float(kanta2_wt or 0),
        is_archive=is_arch,
    )
    db.add(cont)
    db.commit()
    log_audit(db, request, "CONTAINER_ADDED", f"{cno} (NW: {invoice_nw} KG, Archive: {is_arch})")
    tag = " [PURANA RECORD — Live Stock se alag]" if is_arch else ""
    return _redir(f"/?selected_container={quote(cno)}", msg=f"✅ Container {cno} darj ho gaya!{tag}")


@router.post("/action/update-container")
async def action_update_container(
    request: Request,
    sec_key: str = Form(""),
    edit_cno: str = Form(...),
    edit_nw: float = Form(0.0),
    edit_k1_name: str = Form(""),
    edit_k1_wt: float = Form(0.0),
    edit_k2_name: str = Form(""),
    edit_k2_wt: float = Form(0.0),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir(f"/?selected_container={quote(edit_cno)}", err=err)

    cont = db.query(Container).filter(Container.container_no == edit_cno).first()
    if not cont:
        return _redir("/", err="Container nahi mila.")

    if edit_nw > 0:
        cont.invoice_nw = float(edit_nw)
    cont.kanta1_name = edit_k1_name.strip()
    cont.kanta1_wt = float(edit_k1_wt or 0)
    cont.kanta2_name = edit_k2_name.strip()
    cont.kanta2_wt = float(edit_k2_wt or 0)
    db.commit()
    log_audit(db, request, "CONTAINER_UPDATED", f"Updated NW/Kantas for {edit_cno}")
    return _redir(f"/?selected_container={quote(edit_cno)}", msg=f"✅ {edit_cno} ke Invoice NW aur Kanta details update ho gaye!")


@router.post("/action/container-status")
async def action_container_status(
    request: Request,
    sec_key: str = Form(""),
    target_cno: str = Form(...),
    new_status: str = Form("COMPLETED"),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir(f"/?selected_container={quote(target_cno)}", err=err)

    cont = db.query(Container).filter(Container.container_no == target_cno).first()
    if cont:
        cont.status = "OPEN" if new_status == "OPEN" else "COMPLETED"
        db.commit()
        update_all_container_qualities(db)
        log_audit(db, request, "CONTAINER_STATUS", f"{target_cno} -> {cont.status}")
        return _redir(f"/?selected_container={quote(target_cno)}", msg=f"✅ Container {target_cno} ab {cont.status} hai.")
    return _redir("/", err="Container nahi mila.")


@router.post("/action/manual-inward")
async def action_manual_inward(
    request: Request,
    sec_key: str = Form(""),
    container_no: str = Form(...),
    mi_date: str = Form(""),
    mi_workers: int = Form(0),
    mi_remark: str = Form(""),
    mi_cats: List[str] = Form([]),
    mi_items: List[str] = Form([]),
    mi_jambos: List[str] = Form([]),
    mi_weights: List[str] = Form([]),
    mi_particulars: List[str] = Form([]),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/", err=err)

    cont = db.query(Container).filter(Container.container_no == container_no).first()
    if not cont:
        return _redir("/", err="Kripya sahi Container chunein.")

    # PURANA CONTAINER RULE: ARCHIVE_IN never touches Live Stock!
    t_type = "ARCHIVE_IN" if int(cont.is_archive or 0) == 1 else "INWARD"
    dt = _parse_date(mi_date)
    saved = 0
    total_kg = 0.0

    for i, item_raw in enumerate(mi_items):
        iname = (item_raw or "").strip()
        try:
            wt = float(mi_weights[i]) if i < len(mi_weights) and mi_weights[i] else 0.0
        except Exception:
            wt = 0.0
        if not iname or wt <= 0:
            continue
        try:
            jb = int(float(mi_jambos[i])) if i < len(mi_jambos) and mi_jambos[i] else 0
        except Exception:
            jb = 0
        cat = ensure_category_saved(db, mi_cats[i] if i < len(mi_cats) else "Direct Sell")
        part = (mi_particulars[i] if i < len(mi_particulars) else "").strip()

        db.add(Transaction(
            txn_date=dt,
            container_no=cont.container_no,
            item_name=iname,
            txn_type=t_type,
            material_category=cat,
            weight_kg=wt,
            jambo_bag=max(0, jb),
            particular=part,
            workers=max(0, int(mi_workers or 0)),
            remark=mi_remark.strip(),
        ))
        saved += 1
        total_kg += wt

    if saved == 0:
        return _redir("/", err="Koi valid item ya weight nahi mila.")

    db.commit()
    update_all_container_qualities(db)
    log_audit(db, request, "SORTING_INWARD", f"{cont.container_no}: {saved} items, {total_kg:.2f} KG ({t_type})")
    return _redir(
        f"/?selected_container={quote(cont.container_no)}",
        msg=f"✅ {cont.container_no} me {saved} items ({total_kg:,.2f} KG) save ho gaye!",
    )


@router.post("/action/local-stock")
async def action_local_stock(
    request: Request,
    sec_key: str = Form(""),
    material_category: str = Form("Direct Sell"),
    custom_category: str = Form(""),
    local_item: str = Form(...),
    local_jambo: int = Form(0),
    local_wt: float = Form(...),
    local_particular: str = Form(""),
    local_date: str = Form(""),
    local_source: str = Form(""),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/", err=err)

    cat_val = custom_category.strip() if material_category == "__NEW__" and custom_category.strip() else material_category
    cat = ensure_category_saved(db, cat_val)
    iname = local_item.strip()
    if not iname or local_wt <= 0:
        return _redir("/", err="Item Name aur Weight (KG) zaroori hai.")

    db.add(Transaction(
        txn_date=_parse_date(local_date),
        container_no="LOCAL",
        item_name=iname,
        txn_type="LOCAL_IN",
        material_category=cat,
        weight_kg=float(local_wt),
        jambo_bag=max(0, int(local_jambo or 0)),
        party_ref=local_source.strip(),
        particular=local_particular.strip(),
    ))
    db.commit()
    log_audit(db, request, "LOCAL_STOCK_IN", f"{iname} +{local_wt} KG from {local_source}")
    return _redir("/", msg=f"✅ Local Stock +{local_wt:,.2f} KG ({iname}) Live Stock aur Khata me jud gaya!")


@router.post("/action/manual-outward")
async def action_manual_outward(
    request: Request,
    sec_key: str = Form(""),
    mo_party: str = Form(...),
    mo_date: str = Form(""),
    mo_cats: List[str] = Form([]),
    mo_items: List[str] = Form([]),
    mo_jambos: List[str] = Form([]),
    mo_weights: List[str] = Form([]),
    mo_particulars: List[str] = Form([]),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/", err=err)

    party = mo_party.strip()
    if not party:
        return _redir("/", err="Party / Buyer ka naam zaroori hai!")

    dt = _parse_date(mo_date)
    saved = 0
    total_kg = 0.0
    for i, item_raw in enumerate(mo_items):
        iname = (item_raw or "").strip()
        try:
            wt = float(mo_weights[i]) if i < len(mo_weights) and mo_weights[i] else 0.0
        except Exception:
            wt = 0.0
        if not iname or wt <= 0:
            continue
        try:
            jb = int(float(mo_jambos[i])) if i < len(mo_jambos) and mo_jambos[i] else 0
        except Exception:
            jb = 0
        cat = ensure_category_saved(db, mo_cats[i] if i < len(mo_cats) else "Direct Sell")
        part = (mo_particulars[i] if i < len(mo_particulars) else "").strip()

        db.add(Transaction(
            txn_date=dt,
            container_no="DISPATCH",
            item_name=iname,
            txn_type="OUTWARD",
            material_category=cat,
            weight_kg=wt,
            jambo_bag=max(0, jb),
            party_ref=party,
            particular=part,
        ))
        saved += 1
        total_kg += wt

    if saved == 0:
        return _redir("/", err="Koi valid item ya weight nahi mila.")

    db.commit()
    log_audit(db, request, "MANUAL_OUTWARD", f"To {party}: {saved} items, {total_kg:.2f} KG")
    return _redir("/", msg=f"✅ {party} ko {total_kg:,.2f} KG ({saved} items) Outward save ho gaya!")


@router.post("/action/add-return")
async def action_add_return(
    request: Request,
    sec_key: str = Form(""),
    return_type: str = Form("RETURN_IN"),
    material_category: str = Form("Direct Sell"),
    ret_item: str = Form(...),
    ret_jambo: int = Form(0),
    ret_wt: float = Form(...),
    ret_party: str = Form(...),
    ret_reason: str = Form(""),
    ret_container: str = Form(""),
    ret_date: str = Form(""),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/", err=err)

    allowed = {"RETURN_IN", "RETURN_OUT", "JOBWORK_OUT", "JOBWORK_IN"}
    rtype = return_type if return_type in allowed else "RETURN_IN"
    cat = ensure_category_saved(db, material_category)
    dt = _parse_date(ret_date)

    db.add(Transaction(
        txn_date=dt,
        container_no=ret_container.strip() or "RETURN",
        item_name=ret_item.strip(),
        txn_type=rtype,
        material_category=cat,
        weight_kg=float(ret_wt),
        jambo_bag=max(0, int(ret_jambo or 0)),
        party_ref=ret_party.strip(),
        particular=ret_reason.strip(),
        return_reason=ret_reason.strip(),
        linked_container=ret_container.strip(),
        return_date=dt,
    ))
    db.commit()
    log_audit(db, request, rtype, f"{ret_item} {ret_wt} KG ({ret_party})")
    sign = "+" if rtype in ("RETURN_IN", "JOBWORK_IN") else "−"
    return _redir("/", msg=f"✅ {rtype} ({sign}{ret_wt:,.2f} KG {ret_item}) Khata aur Stock me save ho gaya!")


@router.post("/action/confirm-vision")
async def action_confirm_vision(
    request: Request,
    sec_key: str = Form(""),
    v_mode: str = Form("INWARD"),
    v_container_no: str = Form(""),
    v_party: str = Form(""),
    v_date: str = Form(""),
    v_workers: int = Form(0),
    v_remark: str = Form(""),
    final_cats: List[str] = Form([]),
    final_items: List[str] = Form([]),
    final_jambos: List[str] = Form([]),
    final_weights: List[str] = Form([]),
    final_particulars: List[str] = Form([]),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/", err=err)

    is_in = v_mode == "INWARD"
    cno = (v_container_no or "").strip() or ("LOCAL" if is_in else "DISPATCH")
    t_type = "INWARD" if is_in else "OUTWARD"

    if is_in and cno != "LOCAL":
        cont = db.query(Container).filter(Container.container_no == cno).first()
        if cont and int(cont.is_archive or 0) == 1:
            t_type = "ARCHIVE_IN"

    dt = _parse_date(v_date)
    saved = 0
    tot_kg = 0.0

    for i, raw_it in enumerate(final_items):
        iname = (raw_it or "").strip()
        try:
            wt = float(final_weights[i]) if i < len(final_weights) and final_weights[i] else 0.0
        except Exception:
            wt = 0.0
        if not iname or wt <= 0:
            continue
        try:
            jb = int(float(final_jambos[i])) if i < len(final_jambos) and final_jambos[i] else 0
        except Exception:
            jb = 0
        cat = ensure_category_saved(db, final_cats[i] if i < len(final_cats) else "Direct Sell")
        part = (final_particulars[i] if i < len(final_particulars) else "").strip()

        db.add(Transaction(
            txn_date=dt,
            container_no=cno,
            item_name=iname,
            txn_type=t_type,
            material_category=cat,
            weight_kg=wt,
            jambo_bag=max(0, jb),
            party_ref=v_party.strip(),
            particular=part,
            workers=max(0, int(v_workers or 0)) if is_in else 0,
            remark=v_remark.strip(),
        ))
        saved += 1
        tot_kg += wt

    if saved == 0:
        return _redir("/", err="Save karne ke liye kam se kam 1 valid item chahiye.")

    db.commit()
    update_all_container_qualities(db)
    log_audit(db, request, f"PARCHI_{t_type}", f"{cno}: {saved} items, {tot_kg:.2f} KG")
    return _redir("/", msg=f"✅ Parchi ke {saved} items ({tot_kg:,.2f} KG) successfully save ho gaye!")


@router.post("/action/update-live-category")
async def action_update_live_category(
    request: Request,
    sec_key: str = Form(""),
    item_name: str = Form(...),
    old_category: str = Form(...),
    new_category: str = Form(...),
    custom_category: str = Form(""),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/", err=err)

    target_cat = custom_category.strip() if new_category == "__NEW__" and custom_category.strip() else new_category
    target_cat = ensure_category_saved(db, target_cat)

    rows = db.query(Transaction).filter(
        Transaction.item_name == item_name,
        Transaction.material_category == old_category,
    ).all()
    for r in rows:
        r.material_category = target_cat
    db.commit()
    update_all_container_qualities(db)
    log_audit(db, request, "LIVE_CAT_CHANGED", f"{item_name}: {old_category} -> {target_cat}")
    return _redir("/", msg=f"✅ '{item_name}' ki category ab '{target_cat}' ho gayi!")


@router.post("/action/update-txn")
async def action_update_txn(
    request: Request,
    sec_key: str = Form(""),
    txn_id: int = Form(...),
    item_name: str = Form(""),
    material_category: str = Form("Direct Sell"),
    custom_category: str = Form(""),
    jambo_bag: str = Form("0"),
    weight_kg: str = Form("0"),
    party_ref: str = Form(""),
    particular: str = Form(""),
    is_highlighted: str = Form("0"),
    return_to: str = Form("/"),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir(return_to or "/", err=err)

    txn = db.query(Transaction).filter(Transaction.id == txn_id).first()
    if not txn:
        return _redir(return_to or "/", err="Entry nahi mili.")

    cat = custom_category.strip() if material_category == "__NEW__" and custom_category.strip() else material_category
    txn.material_category = ensure_category_saved(db, cat)
    if item_name.strip():
        txn.item_name = item_name.strip()
    try:
        txn.jambo_bag = int(float(jambo_bag or 0))
    except Exception:
        pass
    try:
        w = float(weight_kg or 0)
        if w >= 0:
            txn.weight_kg = w
    except Exception:
        pass
    txn.party_ref = party_ref.strip()
    txn.particular = particular.strip()
    txn.is_highlighted = 1 if is_highlighted == "1" else 0
    db.commit()
    update_all_container_qualities(db)
    log_audit(db, request, "TXN_UPDATED", f"Txn #{txn_id} ({txn.item_name}: {txn.weight_kg} KG)")
    return _redir(return_to or "/", msg=f"✅ Entry #{txn_id} save ho gayi!")


@router.post("/action/delete-txn")
async def action_delete_txn(
    request: Request,
    sec_key: str = Form(""),
    txn_id: int = Form(...),
    return_to: str = Form("/"),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir(return_to or "/", err=err)

    txn = db.query(Transaction).filter(Transaction.id == txn_id).first()
    if txn:
        desc = f"#{txn.id} {txn.item_name} {txn.weight_kg} KG"
        db.delete(txn)
        db.commit()
        update_all_container_qualities(db)
        log_audit(db, request, "TXN_DELETED", desc)
        return _redir(return_to or "/", msg=f"🗑️ Entry {desc} delete kar di gayi.")
    return _redir(return_to or "/", err="Entry nahi mili.")


@router.post("/api/vision")
async def api_vision(
    request: Request,
    v_type: str = Form("INWARD"),
    parchi_img: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    actor = get_current_actor(request, db)
    if actor["is_view_only"]:
        return JSONResponse({"success": False, "error": "View-Only Mode me Parchi upload band hai."}, status_code=403)

    img_bytes = await parchi_img.read()
    if not img_bytes:
        return JSONResponse({"success": False, "error": "Photo khali hai, dobara select karein."})

    res = extract_parchi_from_image(db, img_bytes, parchi_img.content_type or "image/jpeg", v_type=v_type)
    return JSONResponse(res)


@router.post("/api/jyoti")
async def api_jyoti(
    request: Request,
    message: str = Form(""),
    db: Session = Depends(get_db),
):
    actor = get_current_actor(request, db)
    clean_msg = strip_security_code(message)
    if not clean_msg:
        return JSONResponse({"reply": "Ji sir, batayein kya dekhna hai? 🩷"})
    reply = answer_jyoti_query(db, clean_msg, is_view_only=actor["is_view_only"])
    return JSONResponse({"reply": reply})
