import os
import uuid
import shutil
from collections import defaultdict
from datetime import datetime
from typing import List, Optional
from urllib.parse import quote
from fastapi import APIRouter, Request, Depends, Form, UploadFile, File
from fastapi.responses import HTMLResponse, Response
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Container, Transaction, FurnaceBatch, Dispatch, ContainerMedia
from ..security import get_current_actor, get_setting, check_write_permission, log_audit
from ..services import (
    IN_TYPES, OUT_TYPES, get_live_stock, get_khata_data,
    update_all_container_qualities, get_analytics_summary,
    ensure_category_saved, export_excel_workbook, export_json_backup
)
from .auth_admin import base_ctx, templates, _redir

router = APIRouter()


def _guard_login(request: Request, db: Session):
    actor = get_current_actor(request, db)
    if get_setting(db, "require_login", "0") == "1" and not actor["logged_in"]:
        return _redir("/login")
    return None


def _parse_dt(s: str) -> datetime:
    if s:
        try:
            d = datetime.strptime(s.strip(), "%Y-%m-%d")
            now = datetime.now()
            return d.replace(hour=now.hour, minute=now.minute, second=now.second)
        except Exception:
            pass
    return datetime.now()


# =========================================================
# 1. KHATA BOOK — EXCEL SHEET STYLE
# =========================================================
@router.get("/khata", response_class=HTMLResponse)
async def khata_page(
    request: Request,
    item: str = "",
    category: str = "",
    party: str = "",
    type: str = "",
    date_from: str = "",
    date_to: str = "",
    q: str = "",
    db: Session = Depends(get_db),
):
    g = _guard_login(request, db)
    if g:
        return g

    khata = get_khata_data(
        db,
        item_filter=item,
        cat_filter=category,
        party_filter=party,
        type_filter=type,
        date_from=date_from,
        date_to=date_to,
        search_q=q,
    )
    ctx = base_ctx(request, db, "khata")
    ctx.update({
        "khata": khata,
        "f_item": item,
        "f_category": category,
        "f_party": party,
        "f_type": type,
        "f_from": date_from,
        "f_to": date_to,
        "f_q": q,
    })
    return templates.TemplateResponse(request, "khata.html", ctx)


@router.post("/khata/loose-pack")
async def khata_loose_pack(
    request: Request,
    sec_key: str = Form(""),
    item_name: str = Form(...),
    loose_kg: float = Form(...),
    new_jambo: int = Form(1),
    target_category: str = Form("Direct Sell"),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir(f"/khata?item={quote(item_name)}", err=err)

    iname = item_name.strip()
    if not iname or loose_kg <= 0:
        return _redir("/khata", err="Item aur Loose KG (0 se zyada) dalein.")

    now = datetime.now()
    tcat = ensure_category_saved(db, target_category)
    # Deduct from Loose Stock & add packed Jambo to Target Category
    db.add(Transaction(
        txn_date=now,
        container_no="LOOSE-PACK",
        item_name=iname,
        txn_type="OUTWARD",
        material_category="Loose Stock",
        weight_kg=float(loose_kg),
        jambo_bag=0,
        particular=f"Packed into {new_jambo} Jambo ({tcat})",
    ))
    db.add(Transaction(
        txn_date=now,
        container_no="LOOSE-PACK",
        item_name=iname,
        txn_type="INWARD",
        material_category=tcat,
        weight_kg=float(loose_kg),
        jambo_bag=max(1, int(new_jambo or 1)),
        particular=f"Packed from Loose Stock ({loose_kg:g} KG)",
    ))
    db.commit()
    log_audit(db, request, "LOOSE_TO_JAMBO", f"{iname}: {loose_kg} KG -> {new_jambo} Jambo ({tcat})")
    return _redir(f"/khata?item={quote(iname)}", msg=f"✅ {loose_kg:,.2f} KG Loose '{iname}' ab {new_jambo} Jambo ({tcat}) me pack ho gaya!")


# =========================================================
# 2. COPPER FURNACE (BHATTI) & AUTO BURNING LOSS
# =========================================================
@router.get("/furnace", response_class=HTMLResponse)
async def furnace_page(request: Request, db: Session = Depends(get_db)):
    g = _guard_login(request, db)
    if g:
        return g

    batches = db.query(FurnaceBatch).order_by(FurnaceBatch.txn_date.desc(), FurnaceBatch.id.desc()).all()
    tot_in = round(sum(float(b.input_weight or 0) for b in batches), 2)
    tot_out = round(sum(float(b.output_weight or 0) for b in batches), 2)
    tot_loss = round(sum(float(b.burning_loss or 0) for b in batches), 2)
    avg_rec = round((tot_out / tot_in * 100.0), 2) if tot_in > 0 else 0.0
    avg_loss_pct = round((tot_loss / tot_in * 100.0), 2) if tot_in > 0 else 0.0

    stock = get_live_stock(db)
    containers = db.query(Container).order_by(Container.id.desc()).all()

    ctx = base_ctx(request, db, "furnace")
    ctx.update({
        "batches": batches,
        "tot_in": tot_in,
        "tot_out": tot_out,
        "tot_loss": tot_loss,
        "avg_rec": avg_rec,
        "avg_loss_pct": avg_loss_pct,
        "stock": stock,
        "containers": containers,
    })
    return templates.TemplateResponse(request, "furnace.html", ctx)


@router.post("/furnace/add")
async def furnace_add(
    request: Request,
    sec_key: str = Form(""),
    batch_date: str = Form(""),
    furnace_no: str = Form("Furnace 1"),
    input_material: str = Form(...),
    input_category: str = Form("Furnace (Bhatti)"),
    input_weight: float = Form(...),
    input_jambo: int = Form(0),
    input_container: str = Form(""),
    output_material: str = Form(...),
    output_category: str = Form("Direct Sell"),
    output_weight: float = Form(...),
    output_jambo: int = Form(0),
    sync_stock: Optional[str] = Form("1"),
    remark: str = Form(""),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/furnace", err=err)

    in_wt = float(input_weight or 0)
    out_wt = float(output_weight or 0)
    if in_wt <= 0 or out_wt < 0 or out_wt > in_wt * 1.05:
        return _redir("/furnace", err="Input Weight aur Output Weight sahi dalein (Output > Input nahi ho sakta).")

    loss_kg = round(max(0.0, in_wt - out_wt), 2)
    loss_pct = round((loss_kg / in_wt) * 100.0, 2)
    rec_pct = round((out_wt / in_wt) * 100.0, 2)
    dt = _parse_dt(batch_date)

    in_cat = ensure_category_saved(db, input_category)
    out_cat = ensure_category_saved(db, output_category)
    do_sync = 1 if sync_stock else 0

    batch = FurnaceBatch(
        txn_date=dt,
        furnace_no=furnace_no.strip() or "Furnace 1",
        input_material=input_material.strip(),
        input_category=in_cat,
        input_weight=in_wt,
        input_jambo=max(0, int(input_jambo or 0)),
        input_container=input_container.strip(),
        output_material=output_material.strip(),
        output_category=out_cat,
        output_weight=out_wt,
        output_jambo=max(0, int(output_jambo or 0)),
        burning_loss=loss_kg,
        loss_percent=loss_pct,
        recovery_percent=rec_pct,
        synced_stock=do_sync,
        remark=remark.strip(),
    )
    db.add(batch)

    if do_sync:
        db.add(Transaction(
            txn_date=dt,
            container_no="FURNACE",
            item_name=input_material.strip(),
            txn_type="OUTWARD",
            material_category=in_cat,
            weight_kg=in_wt,
            jambo_bag=max(0, int(input_jambo or 0)),
            party_ref=furnace_no.strip(),
            particular=f"Melted in {furnace_no.strip()}",
            remark=remark.strip(),
        ))
        db.add(Transaction(
            txn_date=dt,
            container_no="FURNACE",
            item_name=output_material.strip(),
            txn_type="INWARD",
            material_category=out_cat,
            weight_kg=out_wt,
            jambo_bag=max(0, int(output_jambo or 0)),
            party_ref=furnace_no.strip(),
            particular=f"Output from {furnace_no.strip()} (Rec {rec_pct}% | Loss {loss_kg} KG)",
            remark=remark.strip(),
        ))

    db.commit()
    log_audit(db, request, "FURNACE_BATCH", f"{furnace_no}: {in_wt} KG {input_material} -> {out_wt} KG {output_material} (Loss {loss_pct}%)")
    return _redir("/furnace", msg=f"🔥 Bhatti Batch Save! Recovery: {rec_pct}% | Burning Loss: {loss_kg:,.2f} KG ({loss_pct}%)")


@router.post("/furnace/delete")
async def furnace_delete(
    request: Request,
    sec_key: str = Form(""),
    batch_id: int = Form(...),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/furnace", err=err)

    b = db.query(FurnaceBatch).filter(FurnaceBatch.id == batch_id).first()
    if b:
        db.delete(b)
        db.commit()
        log_audit(db, request, "FURNACE_DELETED", f"Deleted Furnace Batch #{batch_id}")
        return _redir("/furnace", msg=f"🗑️ Bhatti Batch #{batch_id} delete ho gaya.")
    return _redir("/furnace", err="Batch nahi mila.")


# =========================================================
# 3. DISPATCH & VEHICLE LOADING MASTER LEDGER
# =========================================================
def _save_upload_file(up: Optional[UploadFile], subdir: str) -> str:
    if not up or not up.filename:
        return ""
    ext = os.path.splitext(up.filename)[1].lower()[:10] or ".jpg"
    fname = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}{ext}"
    folder = os.path.join("uploads", subdir)
    os.makedirs(folder, exist_ok=True)
    fpath = os.path.join(folder, fname)
    with open(fpath, "wb") as out:
        shutil.copyfileobj(up.file, out)
    return f"/uploads/{subdir}/{fname}"


@router.get("/dispatch", response_class=HTMLResponse)
async def dispatch_page(request: Request, db: Session = Depends(get_db)):
    g = _guard_login(request, db)
    if g:
        return g

    stock = get_live_stock(db)
    dispatches = db.query(Dispatch).order_by(Dispatch.dispatch_date.desc(), Dispatch.id.desc()).limit(100).all()

    outward_txns = (
        db.query(Transaction)
        .filter(Transaction.txn_type.in_(list(OUT_TYPES)))
        .order_by(Transaction.txn_date.desc())
        .all()
    )
    party_summary = defaultdict(lambda: {"kg": 0.0, "jambo": 0, "count": 0})
    for t in outward_txns:
        p = (t.party_ref or "Direct / Unknown").strip() or "Direct / Unknown"
        party_summary[p]["kg"] = round(party_summary[p]["kg"] + float(t.weight_kg or 0), 2)
        party_summary[p]["jambo"] += int(t.jambo_bag or 0)
        party_summary[p]["count"] += 1

    party_rows = sorted(
        [{"party": k, **v} for k, v in party_summary.items()],
        key=lambda x: -x["kg"],
    )

    ctx = base_ctx(request, db, "dispatch")
    ctx.update({
        "stock": stock,
        "dispatches": dispatches,
        "party_rows": party_rows,
    })
    return templates.TemplateResponse(request, "dispatch.html", ctx)


@router.post("/dispatch/add")
async def dispatch_add(
    request: Request,
    sec_key: str = Form(""),
    dispatch_date: str = Form(""),
    invoice_no: str = Form(""),
    party_name: str = Form(...),
    vehicle_no: str = Form(...),
    driver_name: str = Form(""),
    driver_mobile: str = Form(""),
    kanta1_name: str = Form(""),
    kanta1_wt: float = Form(0.0),
    kanta2_name: str = Form(""),
    kanta2_wt: float = Form(0.0),
    party_wt: float = Form(0.0),
    remark: str = Form(""),
    d_cats: List[str] = Form([]),
    d_items: List[str] = Form([]),
    d_jambos: List[str] = Form([]),
    d_weights: List[str] = Form([]),
    vehicle_img: Optional[UploadFile] = File(None),
    rc_img: Optional[UploadFile] = File(None),
    dl_img: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/dispatch", err=err)

    dt = _parse_dt(dispatch_date)
    party = party_name.strip()
    veh = vehicle_no.strip().upper()
    summary_parts = []
    tot_wt = 0.0
    tot_jambo = 0

    for i, raw_it in enumerate(d_items):
        iname = (raw_it or "").strip()
        try:
            wt = float(d_weights[i]) if i < len(d_weights) and d_weights[i] else 0.0
        except Exception:
            wt = 0.0
        if not iname or wt <= 0:
            continue
        try:
            jb = int(float(d_jambos[i])) if i < len(d_jambos) and d_jambos[i] else 0
        except Exception:
            jb = 0
        cat = ensure_category_saved(db, d_cats[i] if i < len(d_cats) else "Direct Sell")

        db.add(Transaction(
            txn_date=dt,
            container_no="DISPATCH",
            item_name=iname,
            txn_type="OUTWARD",
            material_category=cat,
            weight_kg=wt,
            jambo_bag=max(0, jb),
            party_ref=party,
            particular=f"Gaadi {veh} {('Challan ' + invoice_no.strip()) if invoice_no.strip() else ''}".strip(),
            remark=remark.strip(),
        ))
        tot_wt += wt
        tot_jambo += max(0, jb)
        summary_parts.append(f"{iname}: {wt:g} KG ({jb} Bag)")

    if not summary_parts:
        return _redir("/dispatch", err="Kam se kam 1 loading item aur weight dalein.")

    v_path = _save_upload_file(vehicle_img, "dispatch")
    rc_path = _save_upload_file(rc_img, "dispatch")
    dl_path = _save_upload_file(dl_img, "dispatch")

    disp = Dispatch(
        dispatch_date=dt,
        invoice_no=invoice_no.strip(),
        party_name=party,
        vehicle_no=veh,
        driver_name=driver_name.strip(),
        driver_mobile=driver_mobile.strip(),
        item_name=" | ".join(summary_parts),
        total_jambo=tot_jambo,
        hanging_wt=round(tot_wt, 2),
        kanta1_name=kanta1_name.strip(),
        kanta1_wt=float(kanta1_wt or 0),
        kanta2_name=kanta2_name.strip(),
        kanta2_wt=float(kanta2_wt or 0),
        party_wt=float(party_wt or 0),
        vehicle_img=v_path,
        rc_img=rc_path,
        dl_img=dl_path,
        remark=remark.strip(),
    )
    db.add(disp)
    db.commit()
    log_audit(db, request, "VEHICLE_DISPATCH", f"{veh} -> {party} ({tot_wt:.2f} KG)")
    return _redir("/dispatch", msg=f"🚚 Gaadi {veh} ({tot_wt:,.2f} KG → {party}) Dispatch aur Live Stock me update ho gayi!")


@router.post("/dispatch/update-kanta")
async def dispatch_update_kanta(
    request: Request,
    sec_key: str = Form(""),
    dispatch_id: int = Form(...),
    kanta1_name: str = Form(""),
    kanta1_wt: float = Form(0.0),
    kanta2_name: str = Form(""),
    kanta2_wt: float = Form(0.0),
    party_wt: float = Form(0.0),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/dispatch", err=err)

    d = db.query(Dispatch).filter(Dispatch.id == dispatch_id).first()
    if d:
        d.kanta1_name = kanta1_name.strip()
        d.kanta1_wt = float(kanta1_wt or 0)
        d.kanta2_name = kanta2_name.strip()
        d.kanta2_wt = float(kanta2_wt or 0)
        d.party_wt = float(party_wt or 0)
        db.commit()
        log_audit(db, request, "DISPATCH_KANTA_UPDATE", f"Dispatch #{dispatch_id} ({d.vehicle_no})")
        return _redir("/dispatch", msg=f"✅ Gaadi {d.vehicle_no} ka Kanta & Party Weight match update ho gaya!")
    return _redir("/dispatch", err="Dispatch entry nahi mili.")


# =========================================================
# 4. CONTAINER QUALITY RANKING
# =========================================================
@router.get("/quality", response_class=HTMLResponse)
async def quality_page(request: Request, db: Session = Depends(get_db)):
    g = _guard_login(request, db)
    if g:
        return g

    ranked = update_all_container_qualities(db)
    ctx = base_ctx(request, db, "quality")
    ctx["ranked"] = ranked
    return templates.TemplateResponse(request, "quality.html", ctx)


@router.post("/quality/toggle-star")
async def quality_toggle_star(
    request: Request,
    sec_key: str = Form(""),
    container_no: str = Form(...),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/quality", err=err)

    c = db.query(Container).filter(Container.container_no == container_no).first()
    if c:
        c.is_premium_marked = 0 if int(c.is_premium_marked or 0) == 1 else 1
        db.commit()
    return _redir("/quality", msg=f"⭐ {container_no} favorite mark update ho gaya!")


# =========================================================
# 5. OTHER STOCK
# =========================================================
@router.get("/other-stock", response_class=HTMLResponse)
async def other_stock_page(request: Request, db: Session = Depends(get_db)):
    g = _guard_login(request, db)
    if g:
        return g

    stock = get_live_stock(db)
    by_cat = defaultdict(list)
    for r in stock["other_rows"]:
        by_cat[r["material_category"]].append(r)

    ctx = base_ctx(request, db, "other_stock")
    ctx.update({
        "stock": stock,
        "by_cat": dict(by_cat),
        "other_total_kg": round(sum(r["balance"] for r in stock["other_rows"]), 2),
        "other_total_jambo": sum(r["jambo_balance"] for r in stock["other_rows"]),
    })
    return templates.TemplateResponse(request, "other_stock.html", ctx)


# =========================================================
# 6. CONTAINER LIFETIME GALLERY (PHOTO + VIDEO)
# =========================================================
@router.get("/gallery", response_class=HTMLResponse)
async def gallery_page(
    request: Request,
    selected_container: str = "",
    media_type: str = "",
    db: Session = Depends(get_db),
):
    g = _guard_login(request, db)
    if g:
        return g

    containers = db.query(Container).order_by(Container.id.desc()).all()
    q = db.query(ContainerMedia)
    if selected_container:
        q = q.filter(ContainerMedia.container_no == selected_container)
    if media_type in ("photo", "video"):
        q = q.filter(ContainerMedia.media_type == media_type)
    media_items = q.order_by(ContainerMedia.upload_date.desc(), ContainerMedia.id.desc()).all()

    ctx = base_ctx(request, db, "gallery")
    ctx.update({
        "containers": containers,
        "selected_container": selected_container,
        "f_media_type": media_type,
        "media_items": media_items,
    })
    return templates.TemplateResponse(request, "gallery.html", ctx)


@router.post("/gallery/upload")
async def gallery_upload(
    request: Request,
    sec_key: str = Form(""),
    container_no: str = Form(...),
    remark: str = Form(""),
    files: List[UploadFile] = File(...),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir(f"/gallery?selected_container={quote(container_no)}", err=err)

    cno = container_no.strip().upper()
    saved = 0
    folder = os.path.join("uploads", "media")
    os.makedirs(folder, exist_ok=True)

    for up in files:
        if not up or not up.filename:
            continue
        ext = os.path.splitext(up.filename)[1].lower()[:10] or ".jpg"
        fname = f"{cno}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}{ext}"
        fpath = os.path.join(folder, fname)
        size = 0
        with open(fpath, "wb") as out:
            while True:
                chunk = await up.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
                size += len(chunk)
        mtype = "video" if (up.content_type or "").startswith("video") or ext in (".mp4", ".mov", ".webm", ".mkv") else "photo"
        db.add(ContainerMedia(
            container_no=cno,
            media_type=mtype,
            file_path=f"/uploads/media/{fname}",
            file_name=fname,
            original_name=up.filename,
            file_size=size,
            mime_type=up.content_type or "",
            remark=remark.strip(),
        ))
        saved += 1

    db.commit()
    log_audit(db, request, "MEDIA_UPLOADED", f"{cno}: {saved} files uploaded")
    return _redir(f"/gallery?selected_container={quote(cno)}", msg=f"📸 {saved} Photo/Video {cno} gallery me save ho gaye!")


@router.post("/gallery/delete")
async def gallery_delete(
    request: Request,
    sec_key: str = Form(""),
    media_id: int = Form(...),
    db: Session = Depends(get_db),
):
    err = check_write_permission(request, db, sec_key)
    if err:
        return _redir("/gallery", err=err)

    m = db.query(ContainerMedia).filter(ContainerMedia.id == media_id).first()
    if m:
        cno = m.container_no
        local_p = m.file_path.lstrip("/")
        if os.path.isfile(local_p):
            try:
                os.remove(local_p)
            except Exception:
                pass
        db.delete(m)
        db.commit()
        log_audit(db, request, "MEDIA_DELETED", f"Deleted media #{media_id} ({cno})")
        return _redir(f"/gallery?selected_container={quote(cno)}", msg="🗑️ Media file delete kar di gayi.")
    return _redir("/gallery", err="File nahi mili.")


# =========================================================
# 7. STOCK LEDGER & REPORTS & ANALYTICS
# =========================================================
@router.get("/ledger", response_class=HTMLResponse)
async def ledger_page(
    request: Request,
    item: str = "",
    category: str = "",
    party: str = "",
    date_from: str = "",
    date_to: str = "",
    db: Session = Depends(get_db),
):
    g = _guard_login(request, db)
    if g:
        return g

    khata = get_khata_data(db, item_filter=item, cat_filter=category, party_filter=party, date_from=date_from, date_to=date_to)
    # Daily inward vs outward summary
    daily_map = defaultdict(lambda: {"in_kg": 0.0, "out_kg": 0.0})
    for r in khata["rows"]:
        t = r["txn"]
        ds = t.txn_date.strftime("%d-%b-%Y") if t.txn_date else "-"
        if r["is_in"]:
            daily_map[ds]["in_kg"] = round(daily_map[ds]["in_kg"] + float(t.weight_kg or 0), 2)
        else:
            daily_map[ds]["out_kg"] = round(daily_map[ds]["out_kg"] + float(t.weight_kg or 0), 2)

    ctx = base_ctx(request, db, "ledger")
    ctx.update({
        "khata": khata,
        "daily_rows": [{"date": k, **v} for k, v in list(daily_map.items())[:30]],
        "f_item": item,
        "f_category": category,
        "f_party": party,
        "f_from": date_from,
        "f_to": date_to,
    })
    return templates.TemplateResponse(request, "ledger.html", ctx)


@router.get("/reports", response_class=HTMLResponse)
async def reports_page(request: Request, db: Session = Depends(get_db)):
    g = _guard_login(request, db)
    if g:
        return g

    stock = get_live_stock(db)
    txns = db.query(Transaction).order_by(Transaction.txn_date.desc()).all()

    return_txns = [t for t in txns if "RETURN" in (t.txn_type or "") or "JOBWORK" in (t.txn_type or "")][:50]

    party_map = defaultdict(lambda: {"in_kg": 0.0, "out_kg": 0.0, "jambo_in": 0, "jambo_out": 0})
    month_map = defaultdict(lambda: {"in_kg": 0.0, "out_kg": 0.0})

    for t in txns:
        wt = float(t.weight_kg or 0)
        jb = int(t.jambo_bag or 0)
        if t.party_ref:
            p = t.party_ref.strip()
            if t.txn_type in IN_TYPES:
                party_map[p]["in_kg"] = round(party_map[p]["in_kg"] + wt, 2)
                party_map[p]["jambo_in"] += jb
            elif t.txn_type in OUT_TYPES:
                party_map[p]["out_kg"] = round(party_map[p]["out_kg"] + wt, 2)
                party_map[p]["jambo_out"] += jb
        if t.txn_date:
            mk = t.txn_date.strftime("%Y-%m (%b %Y)")
            if t.txn_type in IN_TYPES:
                month_map[mk]["in_kg"] = round(month_map[mk]["in_kg"] + wt, 2)
            elif t.txn_type in OUT_TYPES:
                month_map[mk]["out_kg"] = round(month_map[mk]["out_kg"] + wt, 2)

    party_rows = sorted([{"party": k, **v} for k, v in party_map.items()], key=lambda x: -(x["out_kg"] + x["in_kg"]))
    month_rows = [{"month": k, **v} for k, v in sorted(month_map.items(), reverse=True)[:12]]

    ctx = base_ctx(request, db, "reports")
    ctx.update({
        "stock": stock,
        "return_txns": return_txns,
        "party_rows": party_rows,
        "month_rows": month_rows,
    })
    return templates.TemplateResponse(request, "reports.html", ctx)


@router.get("/analytics", response_class=HTMLResponse)
async def analytics_page(request: Request, db: Session = Depends(get_db)):
    g = _guard_login(request, db)
    if g:
        return g

    summary = get_analytics_summary(db)
    ctx = base_ctx(request, db, "analytics")
    ctx["summary"] = summary
    return templates.TemplateResponse(request, "analytics.html", ctx)


# =========================================================
# 8. EXCEL & JSON BACKUP DOWNLOADS (Works for Admin, Staff & Seth Ji)
# =========================================================
@router.get("/export/excel")
async def export_excel(
    request: Request,
    item: str = "",
    db: Session = Depends(get_db),
):
    g = _guard_login(request, db)
    if g:
        return g

    xlsx_bytes = export_excel_workbook(db, item_filter=item)
    fname = f"Paras_Copper_ERP_{datetime.now().strftime('%d_%b_%Y')}.xlsx"
    return Response(
        content=xlsx_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


@router.get("/export/backup-json")
async def export_backup(request: Request, db: Session = Depends(get_db)):
    actor = get_current_actor(request, db)
    if actor["is_view_only"]:
        return _redir("/seth", err="JSON Backup sirf Admin/Staff download kar sakte hain. Aap Excel Report download karein.")
    json_bytes = export_json_backup(db)
    fname = f"Paras_Copper_Backup_{datetime.now().strftime('%Y%m%d_%H%M')}.json"
    return Response(
        content=json_bytes,
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )
