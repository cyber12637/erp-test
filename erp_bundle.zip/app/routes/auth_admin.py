import json
import secrets
from datetime import datetime
from urllib.parse import quote
from fastapi import APIRouter, Request, Depends, Form, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import (
    Container, Transaction, FurnaceBatch, Dispatch, ContainerMedia,
    ErpUser, ErpApiKey, ErpCategory, ErpAuditLog, ErpSetting
)
from ..security import (
    COOKIE_NAME, make_session_token, get_current_actor, get_setting, set_setting,
    verify_security_pin, get_master_code, log_audit
)
from ..services import (
    get_all_categories, get_live_stock, get_container_report,
    get_analytics_summary, update_all_container_qualities, seed_demo_copper_data
)

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def base_ctx(request: Request, db: Session, active_page: str = "home") -> dict:
    actor = get_current_actor(request, db)
    return {
        "request": request,
        "actor": actor,
        "is_view_only": actor["is_view_only"],
        "is_admin": actor["is_admin"],
        "active_page": active_page,
        "company_name": get_setting(db, "company_name", "PARAS OVERSEAS JHULASAN"),
        "company_subtitle": get_setting(db, "company_subtitle", "Copper & Scrap Division • Live Factory ERP"),
        "categories": get_all_categories(db),
        "msg": request.query_params.get("msg", ""),
        "err": request.query_params.get("err", ""),
        "today_iso": datetime.now().strftime("%Y-%m-%d"),
    }


def _redir(url: str, msg: str = "", err: str = "") -> RedirectResponse:
    sep = "&" if "?" in url else "?"
    if msg:
        url = f"{url}{sep}msg={quote(msg)}"
    elif err:
        url = f"{url}{sep}err={quote(err)}"
    return RedirectResponse(url=url, status_code=303)


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, db: Session = Depends(get_db)):
    ctx = base_ctx(request, db, "login")
    return templates.TemplateResponse(request, "login.html", ctx)


@router.post("/login")
async def login_submit(
    request: Request,
    login_mode: str = Form("user"),
    username: str = Form(""),
    pin_code: str = Form(""),
    db: Session = Depends(get_db),
):
    pin = (pin_code or "").strip()
    uname = (username or "").strip().lower()

    # Quick Seth Ji View-Only login
    if login_mode == "seth_quick":
        seth_pin = get_setting(db, "seth_pin", "1111").strip()
        seth_user = db.query(ErpUser).filter(ErpUser.role == "seth", ErpUser.is_active == 1).first()
        valid_seth = (pin == seth_pin) or (seth_user and pin == seth_user.pin_code)
        if valid_seth:
            if seth_user:
                seth_user.last_login = datetime.now()
                db.commit()
            tok = make_session_token({"username": seth_user.username if seth_user else "seth", "role": "seth"})
            resp = _redir("/seth", msg="🙏 Namaste Seth Ji! Live View-Only Mode chalu hai.")
            resp.set_cookie(COOKIE_NAME, tok, max_age=60 * 60 * 24 * 30, httponly=True, samesite="lax")
            log_audit(db, request, "SETH_LOGIN", "Seth Ji logged in (View-Only)")
            return resp
        return _redir("/login", err="Seth Ji PIN galat hai! Sahi PIN dalein.")

    # Quick Admin login
    if login_mode == "admin_quick":
        admin_user = db.query(ErpUser).filter(ErpUser.role == "admin", ErpUser.is_active == 1).first()
        if verify_security_pin(db, pin) or (admin_user and pin == admin_user.pin_code):
            if admin_user:
                admin_user.last_login = datetime.now()
                db.commit()
            tok = make_session_token({"username": admin_user.username if admin_user else "admin", "role": "admin"})
            resp = _redir("/admin", msg="👑 Admin Control Panel khul gaya!")
            resp.set_cookie(COOKIE_NAME, tok, max_age=60 * 60 * 24 * 14, httponly=True, samesite="lax")
            log_audit(db, request, "ADMIN_LOGIN", "Admin logged in")
            return resp
        return _redir("/login", err="Admin Security Code galat hai!")

    # Standard username + PIN login
    user = db.query(ErpUser).filter(ErpUser.username == uname, ErpUser.is_active == 1).first()
    if not user or user.pin_code != pin:
        return _redir("/login", err="Username ya PIN galat hai!")

    user.last_login = datetime.now()
    db.commit()
    tok = make_session_token({"username": user.username, "role": user.role})
    target = "/seth" if user.role == "seth" else ("/admin" if user.role == "admin" else "/")
    resp = _redir(target, msg=f"✅ Welcome {user.display_name}!")
    resp.set_cookie(COOKIE_NAME, tok, max_age=60 * 60 * 24 * 30, httponly=True, samesite="lax")
    log_audit(db, request, "USER_LOGIN", f"{user.username} ({user.role}) logged in")
    return resp


@router.get("/logout")
async def logout(request: Request):
    resp = _redir("/login", msg="Aap safely logout ho gaye hain.")
    resp.delete_cookie(COOKIE_NAME)
    return resp


@router.get("/seth/access/{token}")
async def seth_magic_access(token: str, request: Request, db: Session = Depends(get_db)):
    expected = get_setting(db, "seth_magic_token", "")
    if not expected or token.strip() != expected.strip():
        return _redir("/login", err="Ye View-Only link expire ya badal diya gaya hai. Naya link Admin se lein.")
    sess = make_session_token({"username": "seth_link", "role": "seth", "magic_token": expected})
    resp = _redir("/seth", msg="🙏 Namaste Seth Ji! Live Factory View-Only Mode Active.")
    resp.set_cookie(COOKIE_NAME, sess, max_age=60 * 60 * 24 * 30, httponly=True, samesite="lax")
    log_audit(db, request, "SETH_LINK_OPENED", "Opened via Seth Ji Secret Link")
    return resp


@router.get("/seth", response_class=HTMLResponse)
async def seth_dashboard(
    request: Request,
    selected_container: str = "",
    db: Session = Depends(get_db),
):
    actor = get_current_actor(request, db)
    if get_setting(db, "require_login", "0") == "1" and not actor["logged_in"]:
        return _redir("/login")

    summary = get_analytics_summary(db)
    all_containers = db.query(Container).order_by(Container.id.desc()).all()
    if not selected_container and all_containers:
        open_cs = [c for c in all_containers if c.status == "OPEN"]
        selected_container = open_cs[0].container_no if open_cs else all_containers[0].container_no

    c_report = get_container_report(db, selected_container) if selected_container else None
    recent_dispatches = db.query(Dispatch).order_by(Dispatch.dispatch_date.desc(), Dispatch.id.desc()).limit(10).all()
    recent_furnace = db.query(FurnaceBatch).order_by(FurnaceBatch.txn_date.desc(), FurnaceBatch.id.desc()).limit(8).all()
    qual_list = update_all_container_qualities(db)[:8]

    ctx = base_ctx(request, db, "seth")
    ctx.update({
        "summary": summary,
        "stock": summary["stock"],
        "all_containers": all_containers,
        "selected_container": selected_container,
        "c_report": c_report,
        "recent_dispatches": recent_dispatches,
        "recent_furnace": recent_furnace,
        "qual_list": qual_list,
    })
    return templates.TemplateResponse(request, "seth_dashboard.html", ctx)


@router.get("/admin", response_class=HTMLResponse)
async def admin_panel(request: Request, db: Session = Depends(get_db)):
    actor = get_current_actor(request, db)
    if actor["is_view_only"]:
        return _redir("/seth", err="👔 Seth Ji View-Only Mode me Admin Panel band rehta hai.")
    if not actor["is_admin"]:
        return _redir("/login", err="👑 Admin Panel kholne ke liye Admin Security Code se login karein.")

    magic_token = get_setting(db, "seth_magic_token", "")
    base_url = str(request.base_url).rstrip("/")
    seth_share_url = f"{base_url}/seth/access/{magic_token}"

    users = db.query(ErpUser).order_by(ErpUser.id.asc()).all()
    keys = db.query(ErpApiKey).order_by(ErpApiKey.provider.asc(), ErpApiKey.id.asc()).all()
    cats = db.query(ErpCategory).order_by(ErpCategory.sort_order.asc(), ErpCategory.id.asc()).all()
    audits = db.query(ErpAuditLog).order_by(ErpAuditLog.id.desc()).limit(40).all()

    stats = {
        "containers": db.query(Container).count(),
        "transactions": db.query(Transaction).count(),
        "furnace_batches": db.query(FurnaceBatch).count(),
        "dispatches": db.query(Dispatch).count(),
        "media_files": db.query(ContainerMedia).count(),
        "active_keys": sum(1 for k in keys if k.is_active == 1),
    }

    ctx = base_ctx(request, db, "admin")
    ctx.update({
        "seth_share_url": seth_share_url,
        "seth_pin": get_setting(db, "seth_pin", "1111"),
        "require_login": get_setting(db, "require_login", "0"),
        "low_stock_threshold": get_setting(db, "low_stock_threshold", "500"),
        "users": users,
        "keys": keys,
        "cats": cats,
        "audits": audits,
        "stats": stats,
    })
    return templates.TemplateResponse(request, "admin.html", ctx)


def _require_admin(request: Request, db: Session) -> bool:
    actor = get_current_actor(request, db)
    return bool(actor["is_admin"] and not actor["is_view_only"])


@router.post("/admin/seth-settings")
async def admin_seth_settings(
    request: Request,
    action_type: str = Form("save"),
    seth_pin: str = Form("1111"),
    require_login: str = Form("0"),
    company_name: str = Form("PARAS OVERSEAS JHULASAN"),
    db: Session = Depends(get_db),
):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")

    if action_type == "regen_link":
        new_tok = secrets.token_urlsafe(18)
        set_setting(db, "seth_magic_token", new_tok)
        log_audit(db, request, "SETH_LINK_REGENERATED", "Generated new Seth Ji View-Only link")
        return _redir("/admin", msg="✅ Naya Seth Ji View-Only Link ban gaya! Purana link band ho gaya.")

    clean_pin = (seth_pin or "1111").strip()
    set_setting(db, "seth_pin", clean_pin)
    set_setting(db, "require_login", "1" if require_login == "1" else "0")
    if company_name.strip():
        set_setting(db, "company_name", company_name.strip())

    # Sync default seth user PIN as well
    s_user = db.query(ErpUser).filter(ErpUser.username == "seth").first()
    if s_user:
        s_user.pin_code = clean_pin
        db.commit()

    log_audit(db, request, "ADMIN_SETH_SETTINGS", f"Updated Seth PIN & login policy (require_login={require_login})")
    return _redir("/admin", msg="✅ Seth Ji View-Only aur Factory Settings save ho gayi!")


@router.post("/admin/security-settings")
async def admin_security_settings(
    request: Request,
    current_pin: str = Form(""),
    new_master_pin: str = Form(""),
    low_stock_threshold: str = Form("500"),
    db: Session = Depends(get_db),
):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")

    if new_master_pin.strip():
        if not verify_security_pin(db, current_pin):
            return _redir("/admin", err="Purana Master Security Code galat hai!")
        np = new_master_pin.strip()
        set_setting(db, "master_code", np)
        adm = db.query(ErpUser).filter(ErpUser.username == "admin").first()
        if adm:
            adm.pin_code = np
            db.commit()
        log_audit(db, request, "MASTER_PIN_UPDATED", "Master Security Code updated")

    try:
        th = str(max(10, int(float(low_stock_threshold or 500))))
        set_setting(db, "low_stock_threshold", th)
    except Exception:
        pass

    return _redir("/admin", msg="✅ Security Settings update ho gayi!")


@router.post("/admin/users/add")
async def admin_add_user(
    request: Request,
    username: str = Form(...),
    display_name: str = Form(...),
    pin_code: str = Form(...),
    role: str = Form("operator"),
    db: Session = Depends(get_db),
):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")

    uname = username.strip().lower()
    if not uname or not pin_code.strip():
        return _redir("/admin", err="Username aur PIN dono zaroori hain.")
    if role not in ("admin", "operator", "seth"):
        role = "operator"

    existing = db.query(ErpUser).filter(ErpUser.username == uname).first()
    if existing:
        existing.display_name = display_name.strip() or uname
        existing.pin_code = pin_code.strip()
        existing.role = role
        existing.is_active = 1
        db.commit()
        log_audit(db, request, "USER_UPDATED", f"Updated user {uname} ({role})")
        return _redir("/admin", msg=f"✅ User '{uname}' update ho gaya!")

    db.add(ErpUser(
        username=uname,
        display_name=display_name.strip() or uname,
        pin_code=pin_code.strip(),
        role=role,
        is_active=1,
    ))
    db.commit()
    log_audit(db, request, "USER_CREATED", f"Created user {uname} ({role})")
    return _redir("/admin", msg=f"✅ Naya user '{uname}' ({role}) ban gaya!")


@router.post("/admin/users/delete")
async def admin_delete_user(
    request: Request,
    user_id: int = Form(...),
    db: Session = Depends(get_db),
):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")
    u = db.query(ErpUser).filter(ErpUser.id == user_id).first()
    if u and u.username not in ("admin",):
        uname = u.username
        db.delete(u)
        db.commit()
        log_audit(db, request, "USER_DELETED", f"Deleted user {uname}")
        return _redir("/admin", msg=f"🗑️ User '{uname}' hata diya gaya.")
    return _redir("/admin", err="Main admin account delete nahi kiya ja sakta.")


@router.post("/admin/keys/bulk-add")
async def admin_bulk_add_keys(
    request: Request,
    provider: str = Form("primary"),
    keys_bulk: str = Form(""),
    db: Session = Depends(get_db),
):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")

    prov = "secondary" if provider == "secondary" else "primary"
    raw_parts = [p.strip() for line in (keys_bulk or "").splitlines() for p in line.split(",")]
    existing = {r.key_value for r in db.query(ErpApiKey).all()}
    added = 0
    current_count = db.query(ErpApiKey).count()
    for part in raw_parts:
        if len(part) > 18 and part not in existing:
            current_count += 1
            db.add(ErpApiKey(
                provider=prov,
                key_value=part,
                label=f"{'Backup' if prov == 'secondary' else 'Reader'} Key #{current_count}",
                is_active=1,
            ))
            existing.add(part)
            added += 1
    db.commit()
    log_audit(db, request, "KEYS_ADDED", f"Added {added} {prov} keys")
    return _redir("/admin", msg=f"✅ {added} Smart Reader Keys rotation pool me jud gayi!")


@router.post("/admin/keys/delete")
async def admin_delete_key(
    request: Request,
    key_id: int = Form(...),
    db: Session = Depends(get_db),
):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")
    row = db.query(ErpApiKey).filter(ErpApiKey.id == key_id).first()
    if row:
        db.delete(row)
        db.commit()
    return _redir("/admin", msg="🗑️ Key hata di gayi.")


@router.post("/admin/categories/add")
async def admin_add_category(
    request: Request,
    cat_name: str = Form(...),
    db: Session = Depends(get_db),
):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")
    cn = (cat_name or "").strip()
    if cn and not db.query(ErpCategory).filter(ErpCategory.name == cn).first():
        db.add(ErpCategory(name=cn, sort_order=25))
        db.commit()
        log_audit(db, request, "CATEGORY_ADDED", cn)
    return _redir("/admin", msg=f"✅ Category '{cn}' add ho gayi!")


@router.post("/admin/categories/delete")
async def admin_del_category(
    request: Request,
    cat_id: int = Form(...),
    db: Session = Depends(get_db),
):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")
    row = db.query(ErpCategory).filter(ErpCategory.id == cat_id).first()
    if row:
        db.delete(row)
        db.commit()
    return _redir("/admin", msg="🗑️ Category hata di gayi.")


@router.post("/admin/demo-seed")
async def admin_demo_seed(request: Request, db: Session = Depends(get_db)):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")
    res = seed_demo_copper_data(db)
    log_audit(db, request, "DEMO_DATA_LOADED", res)
    return _redir("/admin", msg=res)


@router.post("/admin/restore-json")
async def admin_restore_json(
    request: Request,
    backup_file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    if not _require_admin(request, db):
        return _redir("/login", err="Admin login zaroori hai.")
    try:
        raw = await backup_file.read()
        data = json.loads(raw.decode("utf-8"))
        c_added = 0
        t_added = 0
        existing_c = {c.container_no for c in db.query(Container).all()}
        for cd in data.get("containers", []):
            cno = (cd.get("container_no") or "").strip()
            if cno and cno not in existing_c:
                db.add(Container(
                    container_no=cno,
                    invoice_nw=float(cd.get("invoice_nw") or 0),
                    status=cd.get("status") or "OPEN",
                    kanta1_name=cd.get("kanta1_name") or "",
                    kanta1_wt=float(cd.get("kanta1_wt") or 0),
                    kanta2_name=cd.get("kanta2_name") or "",
                    kanta2_wt=float(cd.get("kanta2_wt") or 0),
                    is_archive=int(cd.get("is_archive") or 0),
                ))
                existing_c.add(cno)
                c_added += 1
        for td in data.get("transactions", []):
            db.add(Transaction(
                txn_date=datetime.fromisoformat(td["txn_date"]) if td.get("txn_date") else datetime.now(),
                container_no=td.get("container_no") or "LOCAL",
                item_name=td.get("item_name") or "Item",
                txn_type=td.get("txn_type") or "INWARD",
                material_category=td.get("material_category") or "Direct Sell",
                weight_kg=float(td.get("weight_kg") or 0),
                jambo_bag=int(td.get("jambo_bag") or 0),
                party_ref=td.get("party_ref") or "",
                particular=td.get("particular") or "",
                workers=int(td.get("workers") or 0),
                remark=td.get("remark") or "",
            ))
            t_added += 1
        db.commit()
        update_all_container_qualities(db)
        log_audit(db, request, "BACKUP_RESTORED", f"Restored {c_added} containers, {t_added} txns")
        return _redir("/admin", msg=f"✅ Backup Restore successful! ({c_added} Containers, {t_added} Entries)")
    except Exception as e:
        db.rollback()
        return _redir("/admin", err=f"Backup file invalid hai: {str(e)[:80]}")
