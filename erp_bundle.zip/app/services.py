import io
import json
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from sqlalchemy.orm import Session
from .models import (
    Container, Transaction, FurnaceBatch, Dispatch, ContainerMedia,
    ErpCategory, ErpApiKey, ErpUser, ErpAuditLog, ErpSetting, DEFAULT_CATEGORIES
)
from .security import get_setting

IN_TYPES = {"INWARD", "LOCAL_IN", "RETURN_IN", "JOBWORK_IN"}
OUT_TYPES = {"OUTWARD", "RETURN_OUT", "JOBWORK_OUT"}
OTHER_CAT_KEYWORDS = ("dust", "kachra", "plastic", "uat", "other", "reshort", "return", "jobwork", "loose")
PREMIUM_CATS = {"direct sell", "copper wire", "birch", "berry", "candy", "b-b", "armature", "brass"}


def get_cat_color(cat: str) -> str:
    c = (cat or "").strip().lower()
    if "direct" in c or "sell" in c:
        return "#0d6efd"
    if "furnace" in c or "bhatti" in c:
        return "#dc3545"
    if any(k in c for k in ("copper", "birch", "berry", "candy", "armature", "b-b", "brass")):
        return "#b45309"
    if "dust" in c or "kachra" in c:
        return "#6c757d"
    if "plastic" in c:
        return "#fd7e14"
    if "return" in c:
        return "#d97706"
    if "loose" in c:
        return "#0891b2"
    return "#6f42c1"


def is_other_category(cat: str) -> bool:
    c = (cat or "").strip().lower()
    return any(k in c for k in OTHER_CAT_KEYWORDS)


def get_all_categories(db: Session) -> List[str]:
    seen = set()
    result = []
    for row in db.query(ErpCategory).order_by(ErpCategory.sort_order.asc(), ErpCategory.id.asc()).all():
        n = (row.name or "").strip()
        if n and n.lower() not in seen:
            seen.add(n.lower())
            result.append(n)
    for c in DEFAULT_CATEGORIES:
        if c.lower() not in seen:
            seen.add(c.lower())
            result.append(c)
    for (tc,) in db.query(Transaction.material_category).distinct().all():
        n = (tc or "").strip()
        if n and n.lower() not in seen:
            seen.add(n.lower())
            result.append(n)
    return result


def ensure_category_saved(db: Session, cat_name: str) -> str:
    clean = (cat_name or "Direct Sell").strip() or "Direct Sell"
    exists = db.query(ErpCategory).filter(ErpCategory.name == clean).first()
    if not exists:
        try:
            db.add(ErpCategory(name=clean, sort_order=50))
            db.commit()
        except Exception:
            db.rollback()
    return clean


def get_live_stock(db: Session) -> Dict[str, Any]:
    """
    Computes Live Stock accurately across SQLite, PostgreSQL, and MySQL.
    IMPORTANT: ARCHIVE_IN (Purane Containers) NEVER affects Live Stock!
    """
    txns = db.query(Transaction).filter(
        Transaction.txn_type.in_(list(IN_TYPES | OUT_TYPES))
    ).all()

    grouped: Dict[tuple, Dict[str, Any]] = {}
    for t in txns:
        cat = (t.material_category or "Direct Sell").strip() or "Direct Sell"
        item = (t.item_name or "").strip()
        if not item:
            continue
        key = (cat, item.lower())
        if key not in grouped:
            grouped[key] = {
                "material_category": cat,
                "item_name": item,
                "total_in": 0.0,
                "total_out": 0.0,
                "jambo_in": 0,
                "jambo_out": 0,
            }
        wt = float(t.weight_kg or 0.0)
        jb = int(t.jambo_bag or 0)
        if t.txn_type in IN_TYPES:
            grouped[key]["total_in"] += wt
            grouped[key]["jambo_in"] += jb
        elif t.txn_type in OUT_TYPES:
            grouped[key]["total_out"] += wt
            grouped[key]["jambo_out"] += jb

    all_rows = []
    main_rows = []
    other_rows = []
    cat_summary: Dict[str, Dict[str, Any]] = {}

    for _, g in sorted(grouped.items(), key=lambda x: (x[1]["material_category"].lower(), x[1]["item_name"].lower())):
        bal = round(g["total_in"] - g["total_out"], 2)
        j_bal = g["jambo_in"] - g["jambo_out"]
        row = {
            **g,
            "total_in": round(g["total_in"], 2),
            "total_out": round(g["total_out"], 2),
            "balance": bal,
            "jambo_balance": j_bal,
            "color": get_cat_color(g["material_category"]),
            "is_other": is_other_category(g["material_category"]),
        }
        all_rows.append(row)
        c = g["material_category"]
        if c not in cat_summary:
            cat_summary[c] = {"count": 0, "balance": 0.0, "jambo": 0}
        cat_summary[c]["count"] += 1
        cat_summary[c]["balance"] = round(cat_summary[c]["balance"] + bal, 2)
        cat_summary[c]["jambo"] += j_bal

        if row["is_other"]:
            if abs(bal) > 0.001 or g["total_in"] > 0:
                other_rows.append(row)
        else:
            if abs(bal) > 0.001 or g["total_in"] > 0:
                main_rows.append(row)

    threshold = float(get_setting(db, "low_stock_threshold", "500") or 500)
    low_stocks = [r for r in main_rows if 0 < r["balance"] < threshold]

    total_main_kg = round(sum(r["balance"] for r in main_rows if r["balance"] > 0), 2)
    total_main_jambo = sum(max(0, r["jambo_balance"]) for r in main_rows)
    total_all_kg = round(sum(r["balance"] for r in all_rows if r["balance"] > 0), 2)
    total_all_jambo = sum(max(0, r["jambo_balance"]) for r in all_rows)

    return {
        "all_rows": all_rows,
        "main_rows": main_rows,
        "other_rows": other_rows,
        "cat_summary": cat_summary,
        "low_stocks": low_stocks,
        "total_main_kg": total_main_kg,
        "total_main_jambo": total_main_jambo,
        "total_all_kg": total_all_kg,
        "total_all_jambo": total_all_jambo,
    }


def get_container_report(db: Session, container_no: Optional[str]) -> Optional[Dict[str, Any]]:
    if not container_no:
        return None
    cont = db.query(Container).filter(Container.container_no == container_no).first()
    if not cont:
        return None

    txns = (
        db.query(Transaction)
        .filter(
            Transaction.container_no == container_no,
            Transaction.txn_type.in_(["INWARD", "ARCHIVE_IN"]),
        )
        .order_by(Transaction.txn_date.asc(), Transaction.id.asc())
        .all()
    )

    item_map: Dict[tuple, Dict[str, Any]] = {}
    day_map: Dict[str, Dict[str, Any]] = {}
    total_sorted = 0.0

    for t in txns:
        cat = (t.material_category or "Direct Sell").strip() or "Direct Sell"
        item = (t.item_name or "").strip()
        wt = float(t.weight_kg or 0.0)
        jb = int(t.jambo_bag or 0)
        total_sorted += wt

        ikey = (cat, item)
        if ikey not in item_map:
            item_map[ikey] = {
                "material_category": cat,
                "item_name": item,
                "total_kg": 0.0,
                "total_jambo": 0,
                "color": get_cat_color(cat),
            }
        item_map[ikey]["total_kg"] += wt
        item_map[ikey]["total_jambo"] += jb

        dt = t.txn_date or datetime.now()
        d_iso = dt.strftime("%Y-%m-%d")
        d_disp = dt.strftime("%d-%b-%Y")
        if d_iso not in day_map:
            day_map[d_iso] = {
                "d_iso": d_iso,
                "d_date": d_disp,
                "daily_kg": 0.0,
                "daily_workers": 0,
                "daily_remark": "",
            }
        day_map[d_iso]["daily_kg"] += wt
        if int(t.workers or 0) > day_map[d_iso]["daily_workers"]:
            day_map[d_iso]["daily_workers"] = int(t.workers or 0)
        if t.remark and not day_map[d_iso]["daily_remark"]:
            day_map[d_iso]["daily_remark"] = t.remark

    nw = float(cont.invoice_nw or 0.0)
    items_list = []
    for _, iv in sorted(item_map.items(), key=lambda x: -x[1]["total_kg"]):
        iv["total_kg"] = round(iv["total_kg"], 2)
        iv["share_pct"] = round((iv["total_kg"] / nw * 100.0), 2) if nw > 0 else 0.0
        items_list.append(iv)

    daily_log = []
    total_workers = 0
    for _, dv in sorted(day_map.items(), key=lambda x: x[0]):
        dv["daily_kg"] = round(dv["daily_kg"], 2)
        w = int(dv["daily_workers"] or 0)
        total_workers += w
        dv["avg_per_worker"] = round(dv["daily_kg"] / w, 2) if w > 0 else 0.0
        daily_log.append(dv)

    total_sorted = round(total_sorted, 2)
    diff = round(total_sorted - nw, 2)
    recovery = round((total_sorted / nw * 100.0), 2) if nw > 0 else 0.0

    k1_wt = float(cont.kanta1_wt or 0.0)
    k1_diff = round(total_sorted - k1_wt, 2)
    k1_recovery = round((total_sorted / k1_wt * 100.0), 2) if k1_wt > 0 else 0.0

    k2_wt = float(cont.kanta2_wt or 0.0)
    k2_diff = round(total_sorted - k2_wt, 2)
    k2_recovery = round((total_sorted / k2_wt * 100.0), 2) if k2_wt > 0 else 0.0

    total_days = len(daily_log)
    avg_eff = round(total_sorted / total_workers, 2) if total_workers > 0 else 0.0

    return {
        "info": cont,
        "items": items_list,
        "daily_log": daily_log,
        "total_sorted": total_sorted,
        "diff": diff,
        "recovery": recovery,
        "k1_wt": k1_wt,
        "k1_diff": k1_diff,
        "k1_recovery": k1_recovery,
        "k2_wt": k2_wt,
        "k2_diff": k2_diff,
        "k2_recovery": k2_recovery,
        "total_days": total_days,
        "total_workers": total_workers,
        "avg_eff": avg_eff,
    }


def update_all_container_qualities(db: Session) -> List[Dict[str, Any]]:
    containers = db.query(Container).order_by(Container.id.desc()).all()
    txns = db.query(Transaction).filter(Transaction.txn_type.in_(["INWARD", "ARCHIVE_IN"])).all()

    by_cont: Dict[str, List[Transaction]] = defaultdict(list)
    for t in txns:
        by_cont[t.container_no].append(t)

    ranked = []
    for c in containers:
        c_txns = by_cont.get(c.container_no, [])
        total = sum(float(t.weight_kg or 0) for t in c_txns)
        prem_wt = sum(
            float(t.weight_kg or 0)
            for t in c_txns
            if (t.material_category or "").strip().lower() in PREMIUM_CATS
        )
        dust_wt = sum(
            float(t.weight_kg or 0)
            for t in c_txns
            if any(k in (t.material_category or "").lower() for k in ("dust", "kachra"))
        )
        if total > 0:
            prem_pct = round((prem_wt / total) * 100.0, 2)
            dust_pct = round((dust_wt / total) * 100.0, 2)
            q_score = round(prem_pct - (dust_pct * 0.5), 2)
            if prem_pct >= 75:
                grade = "A+"
            elif prem_pct >= 60:
                grade = "A"
            elif prem_pct >= 40:
                grade = "B"
            elif prem_pct >= 20:
                grade = "C"
            else:
                grade = "D"
            c.premium_percent = prem_pct
            c.quality_score = q_score
            c.quality_grade = grade
        else:
            prem_pct = float(c.premium_percent or 0)
            dust_pct = 0.0
            q_score = float(c.quality_score or 0)
            grade = c.quality_grade or "-"

        nw = float(c.invoice_nw or 0)
        rec_pct = round((total / nw) * 100.0, 2) if nw > 0 else 0.0

        ranked.append({
            "container": c,
            "container_no": c.container_no,
            "invoice_nw": nw,
            "total_sorted": round(total, 2),
            "recovery_pct": rec_pct,
            "premium_wt": round(prem_wt, 2),
            "dust_wt": round(dust_wt, 2),
            "premium_percent": prem_pct,
            "dust_percent": dust_pct,
            "quality_score": q_score,
            "grade": grade,
            "status": c.status,
            "is_archive": c.is_archive,
            "is_premium_marked": c.is_premium_marked,
        })

    try:
        db.commit()
    except Exception:
        db.rollback()

    ranked.sort(key=lambda r: (r["premium_percent"], r["quality_score"], r["total_sorted"]), reverse=True)
    return ranked


def get_khata_data(
    db: Session,
    item_filter: str = "",
    cat_filter: str = "",
    party_filter: str = "",
    type_filter: str = "",
    date_from: str = "",
    date_to: str = "",
    search_q: str = "",
) -> Dict[str, Any]:
    txns = (
        db.query(Transaction)
        .filter(Transaction.txn_type.in_(list(IN_TYPES | OUT_TYPES)))
        .order_by(Transaction.txn_date.asc(), Transaction.id.asc())
        .all()
    )

    # Material cards summary
    mat_cards: Dict[str, Dict[str, Any]] = {}
    parties_set = set()
    for t in txns:
        iname = (t.item_name or "").strip()
        if not iname:
            continue
        mkey = iname.lower()
        if mkey not in mat_cards:
            mat_cards[mkey] = {
                "item_name": iname,
                "category": t.material_category or "Direct Sell",
                "color": get_cat_color(t.material_category or ""),
                "total_in": 0.0,
                "total_out": 0.0,
                "balance_kg": 0.0,
                "balance_jambo": 0,
                "count": 0,
            }
        wt = float(t.weight_kg or 0)
        jb = int(t.jambo_bag or 0)
        if t.txn_type in IN_TYPES:
            mat_cards[mkey]["total_in"] += wt
            mat_cards[mkey]["balance_kg"] += wt
            mat_cards[mkey]["balance_jambo"] += jb
        else:
            mat_cards[mkey]["total_out"] += wt
            mat_cards[mkey]["balance_kg"] -= wt
            mat_cards[mkey]["balance_jambo"] -= jb
        mat_cards[mkey]["count"] += 1
        if t.party_ref:
            parties_set.add(t.party_ref.strip())

    cards_list = sorted(mat_cards.values(), key=lambda x: -x["balance_kg"])
    for c in cards_list:
        c["total_in"] = round(c["total_in"], 2)
        c["total_out"] = round(c["total_out"], 2)
        c["balance_kg"] = round(c["balance_kg"], 2)

    # Filtered ledger with running balance
    running_kg = 0.0
    running_jambo = 0
    filtered_rows = []
    tot_in = 0.0
    tot_out = 0.0
    tot_in_j = 0
    tot_out_j = 0

    dt_from = datetime.strptime(date_from, "%Y-%m-%d") if date_from else None
    dt_to = datetime.strptime(date_to, "%Y-%m-%d") + timedelta(days=1) if date_to else None
    sq = search_q.strip().lower()

    for t in txns:
        if item_filter and (t.item_name or "").strip().lower() != item_filter.strip().lower():
            continue
        if cat_filter and (t.material_category or "").strip().lower() != cat_filter.strip().lower():
            continue
        if party_filter and party_filter.strip().lower() not in (t.party_ref or "").lower():
            continue
        if type_filter == "IN" and t.txn_type not in IN_TYPES:
            continue
        if type_filter == "OUT" and t.txn_type not in OUT_TYPES:
            continue
        if type_filter == "RETURN" and "RETURN" not in (t.txn_type or ""):
            continue
        if dt_from and t.txn_date and t.txn_date < dt_from:
            continue
        if dt_to and t.txn_date and t.txn_date >= dt_to:
            continue
        if sq:
            hay = f"{t.item_name} {t.material_category} {t.container_no} {t.party_ref} {t.particular} {t.remark}".lower()
            if sq not in hay:
                continue

        wt = float(t.weight_kg or 0)
        jb = int(t.jambo_bag or 0)
        is_in = t.txn_type in IN_TYPES
        is_return = "RETURN" in (t.txn_type or "")
        if is_in:
            running_kg += wt
            running_jambo += jb
            tot_in += wt
            tot_in_j += jb
        else:
            running_kg -= wt
            running_jambo -= jb
            tot_out += wt
            tot_out_j += jb

        filtered_rows.append({
            "txn": t,
            "is_in": is_in,
            "is_return": is_return,
            "running_kg": round(running_kg, 2),
            "running_jambo": running_jambo,
            "avg_bag_wt": round(wt / jb, 1) if jb > 0 else 0,
        })

    # Reverse display order (newest on top) while keeping accurate running balance on each row
    filtered_rows.reverse()

    return {
        "cards": cards_list,
        "rows": filtered_rows,
        "parties": sorted(parties_set),
        "tot_in": round(tot_in, 2),
        "tot_out": round(tot_out, 2),
        "net_kg": round(tot_in - tot_out, 2),
        "tot_in_j": tot_in_j,
        "tot_out_j": tot_out_j,
        "net_jambo": tot_in_j - tot_out_j,
    }


def get_analytics_summary(db: Session) -> Dict[str, Any]:
    stock = get_live_stock(db)
    today_str = datetime.now().strftime("%Y-%m-%d")

    txns = db.query(Transaction).all()
    today_in = 0.0
    today_out = 0.0
    daily_in = defaultdict(float)
    daily_out = defaultdict(float)

    for t in txns:
        if not t.txn_date:
            continue
        ds = t.txn_date.strftime("%Y-%m-%d")
        wt = float(t.weight_kg or 0)
        if t.txn_type in IN_TYPES:
            daily_in[ds] += wt
            if ds == today_str:
                today_in += wt
        elif t.txn_type in OUT_TYPES:
            daily_out[ds] += wt
            if ds == today_str:
                today_out += wt

    labels_14 = []
    in_14 = []
    out_14 = []
    for i in range(13, -1, -1):
        d = datetime.now() - timedelta(days=i)
        ds = d.strftime("%Y-%m-%d")
        labels_14.append(d.strftime("%d %b"))
        in_14.append(round(daily_in.get(ds, 0.0), 2))
        out_14.append(round(daily_out.get(ds, 0.0), 2))

    top_items = sorted(
        [r for r in stock["all_rows"] if r["balance"] > 0],
        key=lambda x: -x["balance"],
    )[:10]

    cat_labels = list(stock["cat_summary"].keys())
    cat_values = [max(0.0, round(v["balance"], 2)) for v in stock["cat_summary"].values()]

    containers = db.query(Container).all()
    open_c = sum(1 for c in containers if c.status == "OPEN" and not c.is_archive)
    comp_c = sum(1 for c in containers if c.status == "COMPLETED" and not c.is_archive)
    arch_c = sum(1 for c in containers if c.is_archive)

    qual_list = update_all_container_qualities(db)
    cont_chart_labels = [q["container_no"] for q in qual_list[:8]]
    cont_chart_rec = [q["recovery_pct"] for q in qual_list[:8]]

    batches = db.query(FurnaceBatch).all()
    furnace_in = round(sum(float(b.input_weight or 0) for b in batches), 2)
    furnace_out = round(sum(float(b.output_weight or 0) for b in batches), 2)
    furnace_loss = round(sum(float(b.burning_loss or 0) for b in batches), 2)
    furnace_rec_pct = round((furnace_out / furnace_in * 100.0), 2) if furnace_in > 0 else 0.0

    # WhatsApp Daily KG-Only Summary (Strictly NO Money!)
    wa_lines = [
        f"🏭 *PARAS OVERSEAS JHULASAN — LIVE STOCK REPORT*",
        f"📅 Date: {datetime.now().strftime('%d-%b-%Y %I:%M %p')}",
        f"━━━━━━━━━━━━━━━━━━━━",
        f"📦 *Net Live Stock:* {stock['total_main_kg']:,.2f} KG ({stock['total_main_jambo']} Jambo)",
        f"📥 *Today Inward:* {today_in:,.2f} KG",
        f"🚚 *Today Dispatch:* {today_out:,.2f} KG",
        f"🔓 *Open Containers:* {open_c}",
    ]
    if furnace_in > 0:
        wa_lines.append(f"🔥 *Furnace Recovery:* {furnace_rec_pct:.1f}% (Out: {furnace_out:,.0f} KG)")
    wa_lines.append("━━━━━━━━━━━━━━━━━━━━")
    wa_lines.append("*Top Stock Balances (KG):*")
    for r in top_items[:8]:
        wa_lines.append(f"• {r['item_name']} ({r['material_category']}): *{r['balance']:,.2f} KG* [{r['jambo_balance']} Bag]")

    return {
        "stock": stock,
        "today_in": round(today_in, 2),
        "today_out": round(today_out, 2),
        "open_containers": open_c,
        "completed_containers": comp_c,
        "archive_containers": arch_c,
        "furnace_in": furnace_in,
        "furnace_out": furnace_out,
        "furnace_loss": furnace_loss,
        "furnace_rec_pct": furnace_rec_pct,
        "labels_14": labels_14,
        "in_14": in_14,
        "out_14": out_14,
        "top_item_labels": [r["item_name"] for r in top_items],
        "top_item_values": [r["balance"] for r in top_items],
        "cat_labels": cat_labels,
        "cat_values": cat_values,
        "cont_chart_labels": cont_chart_labels,
        "cont_chart_rec": cont_chart_rec,
        "whatsapp_text": "\n".join(wa_lines),
    }


def export_excel_workbook(db: Session, item_filter: str = "") -> bytes:
    """Generates a multi-sheet .xlsx workbook (Strictly KG, Jambo, Category, Balance — NO Money!)."""
    wb = Workbook()
    header_fill = PatternFill("solid", fgColor="880E4F")
    header_font = Font(color="FFFFFF", bold=True, size=11)
    bold_font = Font(bold=True)
    thin = Side(border_style="thin", color="E5E7EB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    def style_sheet(ws):
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
        for col in ws.columns:
            max_len = max((len(str(c.value or "")) for c in col), default=10)
            ws.column_dimensions[col[0].column_letter].width = min(max(max_len + 4, 12), 38)
        for row in ws.iter_rows(min_row=2):
            for c in row:
                c.border = border

    # Sheet 1: Live Stock
    ws1 = wb.active
    ws1.title = "Live Stock"
    ws1.append(["Category", "Material / Item", "Total In (KG)", "Total Out (KG)", "Net Balance (KG)", "Jambo Balance"])
    stock = get_live_stock(db)
    for r in stock["all_rows"]:
        ws1.append([
            r["material_category"],
            r["item_name"],
            r["total_in"],
            r["total_out"],
            r["balance"],
            r["jambo_balance"],
        ])
    ws1.append(["TOTAL", "", "", "", stock["total_all_kg"], stock["total_all_jambo"]])
    for c in ws1[ws1.max_row]:
        c.font = bold_font
    style_sheet(ws1)

    # Sheet 2: Khata Ledger
    ws2 = wb.create_sheet("Khata Ledger")
    ws2.append(["Date", "Type", "Container / Source", "Category", "Item Name", "Jambo Bag", "Weight (KG)", "Party / Ref", "Particular", "Running Balance (KG)"])
    khata = get_khata_data(db, item_filter=item_filter)
    for r in reversed(khata["rows"]):
        t = r["txn"]
        ws2.append([
            t.txn_date.strftime("%d-%b-%Y %H:%M") if t.txn_date else "",
            t.txn_type,
            t.container_no,
            t.material_category,
            t.item_name,
            t.jambo_bag or 0,
            round(float(t.weight_kg or 0), 2),
            t.party_ref or "",
            t.particular or "",
            r["running_kg"],
        ])
    style_sheet(ws2)

    # Sheet 3: Containers
    ws3 = wb.create_sheet("Containers")
    ws3.append(["Container No", "Status", "Type", "Invoice NW (KG)", "Total Sorted (KG)", "Recovery %", "Quality Grade", "Kanta 1", "Kanta 1 Wt", "Kanta 2", "Kanta 2 Wt"])
    for q in update_all_container_qualities(db):
        c = q["container"]
        ws3.append([
            c.container_no,
            c.status,
            "PURANA RECORD" if c.is_archive else "LIVE",
            c.invoice_nw,
            q["total_sorted"],
            q["recovery_pct"],
            q["grade"],
            c.kanta1_name or "",
            c.kanta1_wt or 0,
            c.kanta2_name or "",
            c.kanta2_wt or 0,
        ])
    style_sheet(ws3)

    # Sheet 4: Furnace Bhatti
    ws4 = wb.create_sheet("Furnace Bhatti")
    ws4.append(["Date", "Furnace", "Input Material", "Input KG", "Input Jambo", "Output Material", "Output KG", "Output Jambo", "Burning Loss KG", "Loss %", "Recovery %", "Remark"])
    for b in db.query(FurnaceBatch).order_by(FurnaceBatch.txn_date.desc()).all():
        ws4.append([
            b.txn_date.strftime("%d-%b-%Y") if b.txn_date else "",
            b.furnace_no,
            b.input_material,
            b.input_weight,
            b.input_jambo,
            b.output_material,
            b.output_weight,
            b.output_jambo,
            b.burning_loss,
            b.loss_percent,
            b.recovery_percent,
            b.remark or "",
        ])
    style_sheet(ws4)

    # Sheet 5: Dispatches
    ws5 = wb.create_sheet("Dispatches")
    ws5.append(["Date", "Challan No", "Party Name", "Vehicle No", "Driver", "Mobile", "Items", "Total Jambo", "Hanging Wt (KG)", "Kanta 1 Wt", "Kanta 2 Wt", "Party Wt"])
    for d in db.query(Dispatch).order_by(Dispatch.dispatch_date.desc()).all():
        ws5.append([
            d.dispatch_date.strftime("%d-%b-%Y") if d.dispatch_date else "",
            d.invoice_no or "",
            d.party_name or "",
            d.vehicle_no or "",
            d.driver_name or "",
            d.driver_mobile or "",
            d.item_name or "",
            d.total_jambo or 0,
            d.hanging_wt or 0,
            d.kanta1_wt or 0,
            d.kanta2_wt or 0,
            d.party_wt or 0,
        ])
    style_sheet(ws5)

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def export_json_backup(db: Session) -> bytes:
    payload = {
        "exported_at": datetime.now().isoformat(),
        "system": "PARAS OVERSEAS JHULASAN - COPPER ERP",
        "containers": [
            {
                "container_no": c.container_no,
                "invoice_nw": c.invoice_nw,
                "status": c.status,
                "kanta1_name": c.kanta1_name,
                "kanta1_wt": c.kanta1_wt,
                "kanta2_name": c.kanta2_name,
                "kanta2_wt": c.kanta2_wt,
                "is_archive": c.is_archive,
                "premium_percent": c.premium_percent,
                "quality_grade": c.quality_grade,
                "quality_score": c.quality_score,
                "is_premium_marked": c.is_premium_marked,
                "created_at": c.created_at.isoformat() if c.created_at else None,
            }
            for c in db.query(Container).all()
        ],
        "transactions": [
            {
                "txn_date": t.txn_date.isoformat() if t.txn_date else None,
                "container_no": t.container_no,
                "item_name": t.item_name,
                "txn_type": t.txn_type,
                "material_category": t.material_category,
                "weight_kg": t.weight_kg,
                "jambo_bag": t.jambo_bag,
                "party_ref": t.party_ref,
                "particular": t.particular,
                "workers": t.workers,
                "remark": t.remark,
                "is_highlighted": t.is_highlighted,
                "return_reason": t.return_reason,
                "linked_container": t.linked_container,
            }
            for t in db.query(Transaction).all()
        ],
        "furnace_batches": [
            {
                "txn_date": b.txn_date.isoformat() if b.txn_date else None,
                "furnace_no": b.furnace_no,
                "input_material": b.input_material,
                "input_category": b.input_category,
                "input_weight": b.input_weight,
                "input_jambo": b.input_jambo,
                "input_container": b.input_container,
                "output_material": b.output_material,
                "output_category": b.output_category,
                "output_weight": b.output_weight,
                "output_jambo": b.output_jambo,
                "burning_loss": b.burning_loss,
                "loss_percent": b.loss_percent,
                "recovery_percent": b.recovery_percent,
                "synced_stock": b.synced_stock,
                "remark": b.remark,
            }
            for b in db.query(FurnaceBatch).all()
        ],
        "dispatches": [
            {
                "dispatch_date": d.dispatch_date.isoformat() if d.dispatch_date else None,
                "invoice_no": d.invoice_no,
                "party_name": d.party_name,
                "vehicle_no": d.vehicle_no,
                "driver_name": d.driver_name,
                "driver_mobile": d.driver_mobile,
                "item_name": d.item_name,
                "total_jambo": d.total_jambo,
                "hanging_wt": d.hanging_wt,
                "kanta1_name": d.kanta1_name,
                "kanta1_wt": d.kanta1_wt,
                "kanta2_name": d.kanta2_name,
                "kanta2_wt": d.kanta2_wt,
                "party_wt": d.party_wt,
                "remark": d.remark,
            }
            for d in db.query(Dispatch).all()
        ],
    }
    return json.dumps(payload, indent=2, ensure_ascii=False).encode("utf-8")


def seed_demo_copper_data(db: Session) -> str:
    """Optional 1-click Copper Factory sample data loader for testing."""
    if db.query(Container).filter(Container.container_no == "MSCU-884210").first():
        return "Sample Copper data pehle se maujood hai."

    now = datetime.now()
    c1 = Container(
        container_no="MSCU-884210",
        invoice_nw=24500.0,
        status="OPEN",
        kanta1_name="Shivam Dharam Kanta",
        kanta1_wt=24460.0,
        kanta2_name="Factory Kanta",
        kanta2_wt=24480.0,
        is_archive=0,
        created_at=now - timedelta(days=3),
    )
    c2 = Container(
        container_no="TGBU-512090",
        invoice_nw=21800.0,
        status="COMPLETED",
        kanta1_name="National Kanta",
        kanta1_wt=21790.0,
        kanta2_name="Factory Kanta",
        kanta2_wt=21785.0,
        is_archive=0,
        created_at=now - timedelta(days=7),
    )
    c3 = Container(
        container_no="OLD-CU-2025",
        invoice_nw=19500.0,
        status="COMPLETED",
        kanta1_name="Jhulasan Kanta",
        kanta1_wt=19480.0,
        is_archive=1,  # Purana Container (Record Only — Live Stock se alag!)
        created_at=now - timedelta(days=20),
    )
    db.add_all([c1, c2, c3])
    db.commit()

    sample_txns = [
        # MSCU-884210 Day 1 & Day 2 Copper Sorting
        Transaction(txn_date=now - timedelta(days=2), container_no="MSCU-884210", item_name="Birch Copper", txn_type="INWARD", material_category="Direct Sell", weight_kg=4250.0, jambo_bag=5, particular="5 Jambo (850+840+860+855+845)", workers=18, remark="Clean bright copper"),
        Transaction(txn_date=now - timedelta(days=2), container_no="MSCU-884210", item_name="Berry Copper Wire", txn_type="INWARD", material_category="Direct Sell", weight_kg=3820.0, jambo_bag=4, particular="4 Jambo", workers=18),
        Transaction(txn_date=now - timedelta(days=1), container_no="MSCU-884210", item_name="Candy Copper", txn_type="INWARD", material_category="Direct Sell", weight_kg=3190.0, jambo_bag=4, particular="Heavy tube copper", workers=20, remark="Fast sorting"),
        Transaction(txn_date=now - timedelta(days=1), container_no="MSCU-884210", item_name="Copper Armature", txn_type="INWARD", material_category="Furnace (Bhatti)", weight_kg=2950.0, jambo_bag=3, particular="Bhatti melting lot", workers=20),
        Transaction(txn_date=now - timedelta(days=1), container_no="MSCU-884210", item_name="PVC Cable Dust", txn_type="INWARD", material_category="Dust / Kachra", weight_kg=410.0, jambo_bag=1, particular="Sorting dust", workers=20),
        # TGBU-512090 Completed Container
        Transaction(txn_date=now - timedelta(days=6), container_no="TGBU-512090", item_name="Birch Copper", txn_type="INWARD", material_category="Direct Sell", weight_kg=9400.0, jambo_bag=11, particular="11 Jambo Grade A", workers=22),
        Transaction(txn_date=now - timedelta(days=5), container_no="TGBU-512090", item_name="Brass Honey", txn_type="INWARD", material_category="Direct Sell", weight_kg=6200.0, jambo_bag=7, particular="Clean brass", workers=21),
        Transaction(txn_date=now - timedelta(days=5), container_no="TGBU-512090", item_name="Copper Armature", txn_type="INWARD", material_category="Furnace (Bhatti)", weight_kg=5400.0, jambo_bag=6, particular="For Bhatti 1", workers=21),
        Transaction(txn_date=now - timedelta(days=5), container_no="TGBU-512090", item_name="Plastic Insulation", txn_type="INWARD", material_category="Plastic", weight_kg=760.0, jambo_bag=2, particular="Cable jacket", workers=21),
        # Local Stock
        Transaction(txn_date=now - timedelta(days=3), container_no="LOCAL", item_name="Millberry Copper", txn_type="LOCAL_IN", material_category="Direct Sell", weight_kg=1850.0, jambo_bag=2, party_ref="Ahmedabad Metal Traders", particular="Local Godown Inward"),
        # Purana Container (ARCHIVE_IN -> Must NOT affect Live Stock!)
        Transaction(txn_date=now - timedelta(days=19), container_no="OLD-CU-2025", item_name="Birch Copper", txn_type="ARCHIVE_IN", material_category="Direct Sell", weight_kg=19420.0, jambo_bag=22, workers=24, remark="Purana record archive"),
        # Furnace Bhatti Melt (Outward Armature -> Inward Copper Ingot/Ladi)
        Transaction(txn_date=now - timedelta(days=1), container_no="FURNACE", item_name="Copper Armature", txn_type="OUTWARD", material_category="Furnace (Bhatti)", weight_kg=3000.0, jambo_bag=3, party_ref="Furnace 1", particular="Sent to Bhatti #1"),
        Transaction(txn_date=now - timedelta(days=1), container_no="FURNACE", item_name="Copper Ladi / Ingot", txn_type="INWARD", material_category="Direct Sell", weight_kg=2790.0, jambo_bag=3, party_ref="Furnace 1", particular="Output from Bhatti #1 (93% Rec)"),
        # Outward Dispatch
        Transaction(txn_date=now, container_no="DISPATCH", item_name="Birch Copper", txn_type="OUTWARD", material_category="Direct Sell", weight_kg=3400.0, jambo_bag=4, party_ref="Shree Ganesh Extrusion", particular="GJ-02-ZZ-4411 Challan #104"),
    ]
    db.add_all(sample_txns)

    fb = FurnaceBatch(
        txn_date=now - timedelta(days=1),
        furnace_no="Furnace 1",
        input_material="Copper Armature",
        input_category="Furnace (Bhatti)",
        input_weight=3000.0,
        input_jambo=3,
        input_container="TGBU-512090",
        output_material="Copper Ladi / Ingot",
        output_category="Direct Sell",
        output_weight=2790.0,
        output_jambo=3,
        burning_loss=210.0,
        loss_percent=7.0,
        recovery_percent=93.0,
        synced_stock=1,
        remark="Clean melt batch",
    )
    db.add(fb)

    disp = Dispatch(
        dispatch_date=now,
        invoice_no="CH-104",
        party_name="Shree Ganesh Extrusion",
        vehicle_no="GJ-02-ZZ-4411",
        driver_name="Rameshbhai",
        driver_mobile="9825012345",
        item_name="Birch Copper: 3400.0 KG (4 Jambo)",
        total_jambo=4,
        hanging_wt=3400.0,
        kanta1_name="Shivam Kanta",
        kanta1_wt=3405.0,
        kanta2_name="Factory Kanta",
        kanta2_wt=3400.0,
        party_wt=3398.0,
        remark="Seal OK",
    )
    db.add(disp)
    db.commit()
    update_all_container_qualities(db)
    return "✅ Sample Copper Factory Data load ho gaya!"
