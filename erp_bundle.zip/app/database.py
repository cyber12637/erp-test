import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

load_dotenv()

def _resolve_database_url() -> str:
    raw = (os.getenv("DATABASE_URL") or "").strip()
    if not raw:
        # Use /data/copper_erp.db if Render persistent disk is mounted at /data
        if os.path.isdir("/data") and os.access("/data", os.W_OK):
            return "sqlite:////data/copper_erp.db"
        return "sqlite:///./copper_erp.db"
    if raw.startswith("postgres://"):
        return raw.replace("postgres://", "postgresql+psycopg2://", 1)
    if raw.startswith("postgresql://") and "+psycopg2" not in raw:
        return raw.replace("postgresql://", "postgresql+psycopg2://", 1)
    if raw.startswith("mysql://"):
        return raw.replace("mysql://", "mysql+pymysql://", 1)
    return raw

DATABASE_URL = _resolve_database_url()

connect_args = {}
engine_kwargs = {"pool_pre_ping": True}
if DATABASE_URL.startswith("sqlite"):
    connect_args = {"check_same_thread": False}
else:
    engine_kwargs["pool_recycle"] = 280

engine = create_engine(DATABASE_URL, connect_args=connect_args, **engine_kwargs)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
