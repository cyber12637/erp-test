import os
import re
import hmac
from datetime import datetime
from typing import Dict, Any, Optional
from fastapi import Request
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from sqlalchemy.orm import Session
from .models import ErpSetting, ErpUser, ErpAuditLog

SECRET_KEY = os.getenv("SECRET_KEY", "paras-overseas-copper-erp-secret-2026")
COOKIE_NAME = "paras_erp_session"
_serializer = URLSafeTimedSerializer(SECRET_KEY)


def get_setting(db: Session, key: str, default: str = "") -> str:
    row = db.query(ErpSetting).filter(ErpSetting.key == key).first()
    if row and row.value is not None:
        return str(row.value)
    return default


def set_setting(db: Session, key: str, value: str) -> None:
    row = db.query(ErpSetting).filter(ErpSetting.key == key).first()
    if row:
        row.value = str(value)
        row.updated_at = datetime.now()
    else:
        db.add(ErpSetting(key=key, value=str(value), updated_at=datetime.now()))
    db.commit()


def get_master_code(db: Session) -> str:
    val = get_setting(db, "master_code", os.getenv("MASTER_CODE", "8808")).strip()
    return val or "8808"


def verify_security_pin(db: Session, provided: Optional[str]) -> bool:
    if not provided:
        return False
    expected = get_master_code(db)
    return hmac.compare_digest(expected.encode("utf-8"), str(provided).strip().encode("utf-8"))


def chat_has_security_code(db: Session, msg: str) -> bool:
    code = re.escape(get_master_code(db))
    return re.search(rf"\[SEC:\s*{code}\s*\]", msg or "", flags=re.IGNORECASE) is not None


def strip_security_code(msg: str) -> str:
    return re.sub(r"\[SEC:[^\]]*\]", "", msg or "", flags=re.IGNORECASE).strip()


def make_session_token(payload: Dict[str, Any]) -> str:
    return _serializer.dumps(payload)


def read_session_token(token: str, max_age: int = 60 * 60 * 24 * 30) -> Optional[Dict[str, Any]]:
    if not token:
        return None
    try:
        data = _serializer.loads(token, max_age=max_age)
        if isinstance(data, dict):
            return data
    except (BadSignature, SignatureExpired, Exception):
        return None
    return None


def get_current_actor(request: Request, db: Session) -> Dict[str, Any]:
    raw_cookie = request.cookies.get(COOKIE_NAME, "")
    data = read_session_token(raw_cookie)
    if data:
        uname = data.get("username", "")
        role = data.get("role", "operator")
        magic = data.get("magic_token", "")
        if role == "seth" and magic:
            # Verify magic token wasn't revoked by Admin
            current_magic = get_setting(db, "seth_magic_token", "")
            if current_magic and hmac.compare_digest(current_magic, magic):
                return {
                    "username": "seth_link",
                    "display_name": "Seth Ji (Live View)",
                    "role": "seth",
                    "is_view_only": True,
                    "is_admin": False,
                    "logged_in": True,
                }
        if uname:
            user = db.query(ErpUser).filter(ErpUser.username == uname, ErpUser.is_active == 1).first()
            if user:
                return {
                    "username": user.username,
                    "display_name": user.display_name,
                    "role": user.role,
                    "is_view_only": user.role == "seth",
                    "is_admin": user.role == "admin",
                    "logged_in": True,
                }

    # Not logged in via cookie -> default factory entry operator (unless require_login == '1')
    return {
        "username": "factory",
        "display_name": "Factory Entry",
        "role": "operator",
        "is_view_only": False,
        "is_admin": False,
        "logged_in": False,
    }


def check_write_permission(request: Request, db: Session, sec_key: Optional[str], require_pin: bool = True) -> Optional[str]:
    """
    Returns None if write is permitted, or a user-facing Hinglish error string if blocked.
    - Blocks Seth View-Only role unconditionally (100% read-only).
    - Verifies Master Security PIN (8808) when require_pin=True.
    """
    actor = get_current_actor(request, db)
    if actor["is_view_only"]:
        return "👔 View-Only Mode Active (Seth Ji View) — Yahan sirf dekh sakte hain, koi badlav save nahi hoga."
    if require_pin and not verify_security_pin(db, sec_key):
        return "🚨 Security Code galat ya missing hai! Sahi code dalein."
    return None


def log_audit(db: Session, request: Request, action: str, details: str = "") -> None:
    try:
        actor = get_current_actor(request, db)
        ip = request.client.host if request.client else ""
        entry = ErpAuditLog(
            actor_name=actor.get("display_name", "Operator"),
            actor_role=actor.get("role", "operator"),
            action=action[:120],
            details=(details or "")[:1000],
            ip_addr=ip[:60],
            created_at=datetime.now(),
        )
        db.add(entry)
        db.commit()
    except Exception:
        db.rollback()
