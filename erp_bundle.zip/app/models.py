import os
import secrets
from datetime import datetime
from sqlalchemy import (
    Column, Integer, BigInteger, String, Float, Text, DateTime, inspect, text
)
from .database import Base, engine, SessionLocal


class Container(Base):
    __tablename__ = "containers"

    id = Column(Integer, primary_key=True, index=True)
    container_no = Column(String(100), unique=True, nullable=False, index=True)
    invoice_nw = Column(Float, nullable=False, default=0.0)
    status = Column(String(30), default="OPEN")  # OPEN, COMPLETED
    kanta1_name = Column(String(100), nullable=True, default="")
    kanta1_wt = Column(Float, default=0.0)
    kanta2_name = Column(String(100), nullable=True, default="")
    kanta2_wt = Column(Float, default=0.0)
    is_archive = Column(Integer, default=0)  # 1 = Purana Record (Live Stock se alag)
    premium_percent = Column(Float, default=0.0)
    quality_grade = Column(String(10), default="B")
    quality_score = Column(Float, default=0.0)
    is_premium_marked = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.now)


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    txn_date = Column(DateTime, default=datetime.now, index=True)
    container_no = Column(String(100), nullable=False, default="LOCAL", index=True)
    item_name = Column(String(150), nullable=False, index=True)
    # INWARD, OUTWARD, LOCAL_IN, ARCHIVE_IN, RETURN_IN, RETURN_OUT, JOBWORK_OUT, JOBWORK_IN
    txn_type = Column(String(30), nullable=False, index=True)
    material_category = Column(String(80), default="Direct Sell", index=True)
    weight_kg = Column(Float, nullable=False, default=0.0)
    jambo_bag = Column(Integer, default=0)
    party_ref = Column(String(255), nullable=True, default="")
    particular = Column(String(255), nullable=True, default="")
    workers = Column(Integer, default=0)
    remark = Column(String(255), nullable=True, default="")
    is_highlighted = Column(Integer, default=0)
    return_reason = Column(String(255), nullable=True, default="")
    linked_container = Column(String(100), nullable=True, default="")
    return_date = Column(DateTime, nullable=True)


class FurnaceBatch(Base):
    __tablename__ = "furnace_batches"

    id = Column(Integer, primary_key=True, index=True)
    txn_date = Column(DateTime, default=datetime.now)
    furnace_no = Column(String(50), default="Furnace 1")
    input_material = Column(String(120), nullable=False)
    input_category = Column(String(100), default="Furnace (Bhatti)")
    input_weight = Column(Float, nullable=False, default=0.0)
    input_jambo = Column(Integer, default=0)
    input_container = Column(String(100), default="")
    output_material = Column(String(120), nullable=False)
    output_category = Column(String(100), default="Direct Sell")
    output_weight = Column(Float, nullable=False, default=0.0)
    output_jambo = Column(Integer, default=0)
    burning_loss = Column(Float, nullable=False, default=0.0)
    loss_percent = Column(Float, nullable=False, default=0.0)
    recovery_percent = Column(Float, nullable=False, default=0.0)
    synced_stock = Column(Integer, default=1)
    remark = Column(String(255), default="")
    created_at = Column(DateTime, default=datetime.now)


class Dispatch(Base):
    __tablename__ = "dispatches"

    id = Column(Integer, primary_key=True, index=True)
    dispatch_date = Column(DateTime, default=datetime.now)
    invoice_no = Column(String(100), nullable=True, default="")
    party_name = Column(String(150), nullable=True, default="")
    vehicle_no = Column(String(50), nullable=True, default="")
    driver_name = Column(String(100), nullable=True, default="")
    driver_mobile = Column(String(30), nullable=True, default="")
    item_name = Column(Text, nullable=True, default="")
    total_jambo = Column(Integer, default=0)
    hanging_wt = Column(Float, default=0.0)
    kanta1_name = Column(String(100), nullable=True, default="")
    kanta1_wt = Column(Float, default=0.0)
    kanta2_name = Column(String(100), nullable=True, default="")
    kanta2_wt = Column(Float, default=0.0)
    party_wt = Column(Float, default=0.0)
    vehicle_img = Column(String(255), nullable=True, default="")
    rc_img = Column(String(255), nullable=True, default="")
    dl_img = Column(String(255), nullable=True, default="")
    remark = Column(String(255), nullable=True, default="")


class ContainerMedia(Base):
    __tablename__ = "container_media"

    id = Column(Integer, primary_key=True, index=True)
    container_no = Column(String(100), nullable=False, index=True)
    media_type = Column(String(20), nullable=False, default="photo")  # photo, video
    file_path = Column(String(500), nullable=False)
    file_name = Column(String(255), nullable=False)
    original_name = Column(String(255), nullable=True, default="")
    file_size = Column(BigInteger, default=0)
    mime_type = Column(String(100), nullable=True, default="")
    remark = Column(String(255), nullable=True, default="")
    upload_date = Column(DateTime, default=datetime.now)


class ErpUser(Base):
    __tablename__ = "erp_users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(60), unique=True, nullable=False, index=True)
    display_name = Column(String(120), nullable=False)
    pin_code = Column(String(120), nullable=False)
    role = Column(String(30), nullable=False, default="operator")  # admin, operator, seth
    is_active = Column(Integer, default=1)
    last_login = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now)


class ErpApiKey(Base):
    __tablename__ = "erp_api_keys"

    id = Column(Integer, primary_key=True, index=True)
    provider = Column(String(30), default="primary")  # primary, secondary
    key_value = Column(String(300), nullable=False)
    label = Column(String(100), default="")
    is_active = Column(Integer, default=1)
    usage_count = Column(Integer, default=0)
    fail_count = Column(Integer, default=0)
    last_used_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now)


class ErpCategory(Base):
    __tablename__ = "erp_categories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(80), unique=True, nullable=False)
    sort_order = Column(Integer, default=10)
    created_at = Column(DateTime, default=datetime.now)


class ErpSetting(Base):
    __tablename__ = "erp_settings"

    key = Column(String(80), primary_key=True)
    value = Column(Text, nullable=True, default="")
    updated_at = Column(DateTime, default=datetime.now)


class ErpAuditLog(Base):
    __tablename__ = "erp_audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    actor_name = Column(String(100), default="Operator")
    actor_role = Column(String(30), default="operator")
    action = Column(String(120), nullable=False)
    details = Column(Text, default="")
    ip_addr = Column(String(60), default="")
    created_at = Column(DateTime, default=datetime.now)


DEFAULT_CATEGORIES = [
    "Direct Sell",
    "Furnace (Bhatti)",
    "Copper Wire",
    "Birch",
    "Berry",
    "Candy",
    "Armature",
    "B-B",
    "Brass",
    "Dust / Kachra",
    "Plastic",
    "UAT (Other)",
    "RESHORTING",
    "Loose Stock",
    "Return Stock",
    "Jobwork",
]


def _ensure_missing_columns():
    """Safely add missing columns if connecting to an older existing MySQL/Postgres DB."""
    insp = inspect(engine)
    migrations = {
        "containers": [
            ("kanta1_name", "VARCHAR(100)"),
            ("kanta1_wt", "FLOAT DEFAULT 0"),
            ("kanta2_name", "VARCHAR(100)"),
            ("kanta2_wt", "FLOAT DEFAULT 0"),
            ("is_archive", "INTEGER DEFAULT 0"),
            ("premium_percent", "FLOAT DEFAULT 0"),
            ("quality_grade", "VARCHAR(10) DEFAULT 'B'"),
            ("quality_score", "FLOAT DEFAULT 0"),
            ("is_premium_marked", "INTEGER DEFAULT 0"),
        ],
        "transactions": [
            ("material_category", "VARCHAR(80) DEFAULT 'Direct Sell'"),
            ("jambo_bag", "INTEGER DEFAULT 0"),
            ("party_ref", "VARCHAR(255)"),
            ("particular", "VARCHAR(255)"),
            ("workers", "INTEGER DEFAULT 0"),
            ("remark", "VARCHAR(255)"),
            ("is_highlighted", "INTEGER DEFAULT 0"),
            ("return_reason", "VARCHAR(255)"),
            ("linked_container", "VARCHAR(100)"),
            ("return_date", "TIMESTAMP NULL"),
        ],
        "furnace_batches": [
            ("input_jambo", "INTEGER DEFAULT 0"),
            ("input_container", "VARCHAR(100) DEFAULT ''"),
            ("output_category", "VARCHAR(100) DEFAULT 'Direct Sell'"),
            ("output_jambo", "INTEGER DEFAULT 0"),
            ("synced_stock", "INTEGER DEFAULT 1"),
            ("remark", "VARCHAR(255) DEFAULT ''"),
        ],
        "dispatches": [
            ("total_jambo", "INTEGER DEFAULT 0"),
            ("kanta1_name", "VARCHAR(100)"),
            ("kanta1_wt", "FLOAT DEFAULT 0"),
            ("kanta2_name", "VARCHAR(100)"),
            ("kanta2_wt", "FLOAT DEFAULT 0"),
            ("party_wt", "FLOAT DEFAULT 0"),
            ("remark", "VARCHAR(255)"),
        ],
    }
    for table_name, cols in migrations.items():
        if not insp.has_table(table_name):
            continue
        existing = {c["name"].lower() for c in insp.get_columns(table_name)}
        for col_name, col_def in cols:
            if col_name.lower() not in existing:
                try:
                    with engine.begin() as conn:
                        conn.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {col_name} {col_def}"))
                except Exception:
                    pass


def init_db():
    Base.metadata.create_all(bind=engine)
    _ensure_missing_columns()

    db = SessionLocal()
    try:
        master_code = (os.getenv("MASTER_CODE") or "8808").strip()
        seth_pin = (os.getenv("SETH_PIN") or "1111").strip()

        defaults = {
            "company_name": "PARAS OVERSEAS JHULASAN",
            "company_subtitle": "Copper & Scrap Division • Live Factory ERP",
            "master_code": master_code,
            "seth_pin": seth_pin,
            "seth_magic_token": secrets.token_urlsafe(18),
            "require_login": "0",
            "low_stock_threshold": "500",
        }
        for k, v in defaults.items():
            if not db.query(ErpSetting).filter(ErpSetting.key == k).first():
                db.add(ErpSetting(key=k, value=v))
        db.commit()

        # Seed default users (Admin, Factory Operator, Seth Ji View-Only)
        if not db.query(ErpUser).filter(ErpUser.username == "admin").first():
            db.add(ErpUser(
                username="admin",
                display_name="Admin (Full Control)",
                pin_code=master_code,
                role="admin",
                is_active=1,
            ))
        if not db.query(ErpUser).filter(ErpUser.username == "seth").first():
            db.add(ErpUser(
                username="seth",
                display_name="Seth Ji (Live View-Only)",
                pin_code=seth_pin,
                role="seth",
                is_active=1,
            ))
        if not db.query(ErpUser).filter(ErpUser.username == "staff").first():
            db.add(ErpUser(
                username="staff",
                display_name="Factory Munim / Entry",
                pin_code="2222",
                role="operator",
                is_active=1,
            ))
        db.commit()

        # Seed default Copper & Scrap categories
        if db.query(ErpCategory).count() == 0:
            for idx, cname in enumerate(DEFAULT_CATEGORIES, start=1):
                db.add(ErpCategory(name=cname, sort_order=idx))
            db.commit()

        # Seed env reader keys if provided
        env_primary = (os.getenv("PRIMARY_READER_KEY") or os.getenv("GEMINI_API_KEY") or "").strip()
        env_extra = (os.getenv("EXTRA_READER_KEYS") or os.getenv("GEMINI_KEYS_EXTRA") or "").strip()
        env_sec = (os.getenv("SECONDARY_READER_KEY") or os.getenv("GROQ_API_KEY") or "").strip()

        existing_vals = {r.key_value for r in db.query(ErpApiKey).all()}
        raw_p_keys = [env_primary] + [x.strip() for x in env_extra.split(",") if x.strip()]
        for i, kv in enumerate(raw_p_keys, start=1):
            if kv and len(kv) > 18 and kv not in existing_vals:
                db.add(ErpApiKey(provider="primary", key_value=kv, label=f"Env Key #{i}", is_active=1))
                existing_vals.add(kv)
        if env_sec and len(env_sec) > 18 and env_sec not in existing_vals:
            db.add(ErpApiKey(provider="secondary", key_value=env_sec, label="Secondary Backup Key", is_active=1))
        db.commit()
    finally:
        db.close()
