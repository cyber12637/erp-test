import os
import re
import json
import base64
from datetime import datetime
from typing import List, Dict, Any, Tuple
import requests
from sqlalchemy.orm import Session
from .models import ErpApiKey, Container, Transaction, FurnaceBatch, Dispatch
from .services import get_live_stock, get_container_report

TOTAL_PATTERNS = re.compile(
    r"(^|\b)(total|grand\s*total|sub\s*total|subtotal|kul|kul\s*wajan|sum|net\s*total|all\s*total|g\.?\s*total|टोटल|कुल|योग)(\b|$)",
    re.IGNORECASE,
)


def guess_category_for_item(item_name: str) -> str:
    s = (item_name or "").strip().lower()
    if any(k in s for k in ("bhatti", "furnace", "armature", "motor", "jalal", "burn")):
        return "Furnace (Bhatti)"
    if any(k in s for k in ("dust", "kachra", "mitti", "ash", "sweeping")):
        return "Dust / Kachra"
    if any(k in s for k in ("plastic", "pvc", "rubber", "insulation", "jacket")):
        return "Plastic"
    if "loose" in s:
        return "Loose Stock"
    return "Direct Sell"


def clean_and_calculate_parchi_items(raw_items: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    1. Removes any TOTAL / SUBTOTAL / KUL summary line by keyword.
    2. Removes mathematical subtotal lines per material (e.g. 5 Birch bags + 6th line = sum of 5 bags -> keeps only 5!).
    3. Removes mathematical grand total line at end if it equals sum of all previous items.
    4. Auto-calculates general per-item totals (Jambo count + exact KG sum + breakdown string) for ALL materials!
    """
    step1: List[Dict[str, Any]] = []
    for r in raw_items:
        if not isinstance(r, dict):
            continue
        name = str(r.get("item") or r.get("item_name") or r.get("material") or "").strip()
        # Strip numbering prefixes like "1." or "#2"
        name = re.sub(r"^\s*\d+[\.\)\-:]\s*", "", name).strip()
        if not name or TOTAL_PATTERNS.search(name):
            continue
        # Reject pure punctuation/numbers as item name
        if re.fullmatch(r"[\d\W_]+", name):
            continue
        try:
            wt = float(str(r.get("weight") or r.get("weight_kg") or 0).replace(",", "").strip())
        except Exception:
            wt = 0.0
        if wt <= 0:
            continue
        try:
            jb = int(float(r.get("jambo") or r.get("jambo_bag") or 1))
        except Exception:
            jb = 1
        if jb < 0:
            jb = 1

        cat = str(r.get("category") or "").strip() or guess_category_for_item(name)
        part = str(r.get("particular") or "").strip()
        step1.append({
            "item": name,
            "weight": round(wt, 2),
            "jambo": jb if jb > 0 else 1,
            "category": cat,
            "particular": part,
        })

    # Step 2: Detect mathematical grand-total at the end of list
    if len(step1) >= 3:
        prev_sum = sum(x["weight"] for x in step1[:-1])
        if abs(step1[-1]["weight"] - prev_sum) <= 2.0:
            step1 = step1[:-1]

    # Step 3: Detect mathematical per-item subtotal row (e.g. 5 Birch jambos + 6th line equal to sum of those 5)
    by_norm: Dict[str, List[int]] = {}
    for idx, row in enumerate(step1):
        norm = re.sub(r"\s+", " ", row["item"].strip().lower())
        by_norm.setdefault(norm, []).append(idx)

    drop_indices = set()
    for norm, idxs in by_norm.items():
        if len(idxs) >= 3:
            last_idx = idxs[-1]
            preceding_sum = sum(step1[i]["weight"] for i in idxs[:-1])
            if abs(step1[last_idx]["weight"] - preceding_sum) <= 1.5:
                drop_indices.add(last_idx)

    individual_items = [r for i, r in enumerate(step1) if i not in drop_indices]

    # Step 4: General Auto-Calculation across ALL items (groups multiple bags of any item into exact sum + jambo count)
    grouped_map: Dict[str, Dict[str, Any]] = {}
    order_keys: List[str] = []
    for r in individual_items:
        norm = re.sub(r"\s+", " ", r["item"].strip().lower())
        if norm not in grouped_map:
            order_keys.append(norm)
            grouped_map[norm] = {
                "item": r["item"],
                "category": r["category"],
                "weights_list": [],
                "jambo": 0,
                "weight": 0.0,
                "particulars": [],
            }
        g = grouped_map[norm]
        g["weights_list"].append(r["weight"])
        g["jambo"] += int(r["jambo"] or 1)
        g["weight"] = round(g["weight"] + r["weight"], 2)
        if r["particular"]:
            g["particulars"].append(r["particular"])

    grouped_items = []
    for k in order_keys:
        g = grouped_map[k]
        w_list = g["weights_list"]
        if len(w_list) > 1:
            w_str = " + ".join(f"{w:g}" for w in w_list[:12])
            if len(w_list) > 12:
                w_str += " + ..."
            auto_part = f"{g['jambo']} Jambo ({w_str} = {g['weight']:g} KG)"
        else:
            auto_part = g["particulars"][0] if g["particulars"] else (f"{g['jambo']} Jambo" if g["jambo"] > 0 else "")
        grouped_items.append({
            "item": g["item"],
            "category": g["category"],
            "jambo": g["jambo"],
            "weight": g["weight"],
            "particular": auto_part,
            "bag_count": len(w_list),
        })

    grand_kg = round(sum(x["weight"] for x in individual_items), 2)
    grand_jambo = sum(x["jambo"] for x in individual_items)

    return {
        "individual_items": individual_items,
        "grouped_items": grouped_items,
        "grand_kg": grand_kg,
        "grand_jambo": grand_jambo,
    }


def _collect_keys(db: Session) -> Tuple[List[Tuple[int, str]], List[Tuple[int, str]]]:
    primary_rows = (
        db.query(ErpApiKey)
        .filter(ErpApiKey.provider == "primary", ErpApiKey.is_active == 1)
        .order_by(ErpApiKey.fail_count.asc(), ErpApiKey.usage_count.asc(), ErpApiKey.id.asc())
        .all()
    )
    secondary_rows = (
        db.query(ErpApiKey)
        .filter(ErpApiKey.provider == "secondary", ErpApiKey.is_active == 1)
        .order_by(ErpApiKey.fail_count.asc(), ErpApiKey.id.asc())
        .all()
    )
    prim = [(r.id, r.key_value.strip()) for r in primary_rows if r.key_value and len(r.key_value.strip()) > 18]
    sec = [(r.id, r.key_value.strip()) for r in secondary_rows if r.key_value and len(r.key_value.strip()) > 18]

    # Also check env fallback if DB has none
    if not prim:
        ep = (os.getenv("PRIMARY_READER_KEY") or os.getenv("GEMINI_API_KEY") or "").strip()
        ex = (os.getenv("EXTRA_READER_KEYS") or os.getenv("GEMINI_KEYS_EXTRA") or "").strip()
        for k in [ep] + [x.strip() for x in ex.split(",") if x.strip()]:
            if k and len(k) > 18:
                prim.append((0, k))
    if not sec:
        es = (os.getenv("SECONDARY_READER_KEY") or os.getenv("GROQ_API_KEY") or "").strip()
        if es and len(es) > 18:
            sec.append((0, es))

    return prim, sec


def _mark_key_result(db: Session, key_id: int, ok: bool) -> None:
    if not key_id:
        return
    try:
        row = db.query(ErpApiKey).filter(ErpApiKey.id == key_id).first()
        if row:
            if ok:
                row.usage_count = int(row.usage_count or 0) + 1
                row.last_used_at = datetime.now()
            else:
                row.fail_count = int(row.fail_count or 0) + 1
            db.commit()
    except Exception:
        db.rollback()


def extract_parchi_from_image(db: Session, img_bytes: bytes, mime_type: str, v_type: str = "INWARD") -> Dict[str, Any]:
    prim_keys, sec_keys = _collect_keys(db)
    if not prim_keys and not sec_keys:
        return {
            "success": False,
            "error": "Smart Parchi Reader Key abhi set nahi hai. Admin Panel → Keys me key dalein ya Manual Entry use karein.",
        }

    b64 = base64.b64encode(img_bytes).decode("utf-8")
    prompt = (
        "Read this handwritten or printed factory weight slip (parchi) very carefully. "
        "Extract EVERY individual material/bag weight line separately in KG. "
        "STRICT RULES:\n"
        "1. NEVER include any Total, Sub-total, Kul Wajan, or Grand Total line as an item.\n"
        "2. If an item (for example Birch, Berry, Candy, Copper, Armature, Brass, etc.) has 5 individual bag weights written and a sum/total below them, output ONLY the 5 individual bag lines — NEVER output the 6th total line.\n"
        "3. Standardize material names cleanly.\n"
        "4. Return STRICT JSON array only: [{\"item\": \"Birch\", \"weight\": 412.5, \"jambo\": 1}]. No extra text."
    )

    models_primary = ["gemini-2.0-flash", "gemini-1.5-flash"]

    # 1. Try Primary 100-Key Rotation Pool
    for key_id, api_key in prim_keys:
        for model_name in models_primary:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={api_key}"
            payload = {
                "contents": [{
                    "parts": [
                        {"text": prompt},
                        {"inline_data": {"mime_type": mime_type or "image/jpeg", "data": b64}},
                    ]
                }],
                "generationConfig": {"response_mime_type": "application/json", "temperature": 0.1},
            }
            try:
                resp = requests.post(url, json=payload, timeout=30)
                if resp.status_code == 200:
                    data = resp.json()
                    txt = (
                        data.get("candidates", [{}])[0]
                        .get("content", {})
                        .get("parts", [{}])[0]
                        .get("text", "")
                    )
                    cleaned = re.sub(r"```json|```", "", txt, flags=re.IGNORECASE).strip()
                    parsed = json.loads(cleaned)
                    if isinstance(parsed, dict) and "items" in parsed:
                        parsed = parsed["items"]
                    if isinstance(parsed, list) and len(parsed) > 0:
                        _mark_key_result(db, key_id, True)
                        calc = clean_and_calculate_parchi_items(parsed)
                        if calc["individual_items"]:
                            return {"success": True, **calc}
            except Exception:
                pass
        _mark_key_result(db, key_id, False)

    # 2. Try Secondary Backup Pool
    for key_id, sec_key in sec_keys:
        try:
            resp = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization": f"Bearer {sec_key}", "Content-Type": "application/json"},
                json={
                    "model": "meta-llama/llama-4-scout-17b-16e-instruct",
                    "temperature": 0.1,
                    "messages": [{
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:{mime_type or 'image/jpeg'};base64,{b64}"}},
                        ],
                    }],
                },
                timeout=30,
            )
            if resp.status_code == 200:
                txt = resp.json()["choices"][0]["message"]["content"]
                m = re.search(r"\[.*\]", txt, flags=re.DOTALL)
                cleaned = m.group(0) if m else re.sub(r"```json|```", "", txt).strip()
                parsed = json.loads(cleaned)
                if isinstance(parsed, list) and len(parsed) > 0:
                    _mark_key_result(db, key_id, True)
                    calc = clean_and_calculate_parchi_items(parsed)
                    if calc["individual_items"]:
                        return {"success": True, **calc}
        except Exception:
            pass
        _mark_key_result(db, key_id, False)

    return {
        "success": False,
        "error": "Parchi saaf nahi padhi ja saki ya key limit poori hui. Dobara saaf photo lein ya Manual Entry karein.",
    }


def answer_jyoti_query(db: Session, raw_message: str, is_view_only: bool = False) -> str:
    """
    Fast, accurate Hinglish factory assistant powered directly by live database + optional smart text engine.
    Zero external brand names ever mentioned!
    """
    q = (raw_message or "").strip()
    ql = q.lower()
    stock = get_live_stock(db)

    # 1. Instant smart database answers (works 100% offline/without keys too!)
    if any(w in ql for w in ("live stock", "kul stock", "total stock", "kitna maal", "stock dikhao", "stock batao")):
        if not stock["all_rows"]:
            return "Sir, abhi Live Stock me koi entry nahi hai. Naya Container ya Local Stock se shuru karein! 📦"
        lines = [f"📦 <b>Live Stock Summary ({stock['total_main_kg']:,.2f} KG | {stock['total_main_jambo']} Jambo):</b>"]
        for r in stock["main_rows"][:10]:
            lines.append(f"• <b>{r['item_name']}</b> ({r['material_category']}): {r['balance']:,.2f} KG [{r['jambo_balance']} Bag]")
        if stock["other_rows"]:
            other_kg = sum(x["balance"] for x in stock["other_rows"])
            lines.append(f"• <i>Other Stock ({len(stock['other_rows'])} items): {other_kg:,.2f} KG</i>")
        return "<br>".join(lines)

    if "furnace" in ql or "bhatti" in ql or "burning" in ql:
        batches = db.query(FurnaceBatch).order_by(FurnaceBatch.id.desc()).limit(5).all()
        if not batches:
            return "🔥 Abhi Furnace (Bhatti) me koi batch record nahi hai. Upar <b>🔥 Furnace</b> tab se entry karein."
        tot_in = sum(float(b.input_weight or 0) for b in batches)
        tot_out = sum(float(b.output_weight or 0) for b in batches)
        rec = (tot_out / tot_in * 100.0) if tot_in > 0 else 0
        lines = [f"🔥 <b>Last {len(batches)} Bhatti Batches (Avg Recovery: {rec:.1f}%):</b>"]
        for b in batches:
            lines.append(f"• {b.furnace_no}: {b.input_material} ({b.input_weight:g} KG) → <b>{b.output_material} ({b.output_weight:g} KG)</b> | Loss: {b.loss_percent:g}%")
        return "<br>".join(lines)

    if "dispatch" in ql or "gaadi" in ql or "sell" in ql or "outward" in ql:
        disps = db.query(Dispatch).order_by(Dispatch.id.desc()).limit(5).all()
        if not disps:
            return "🚚 Abhi koi vehicle dispatch entry nahi hai."
        lines = ["🚚 <b>Recent Dispatches:</b>"]
        for d in disps:
            dt = d.dispatch_date.strftime("%d-%b") if d.dispatch_date else ""
            lines.append(f"• {dt} | <b>{d.party_name}</b> ({d.vehicle_no}) — {d.hanging_wt:g} KG [{d.item_name}]")
        return "<br>".join(lines)

    if "container" in ql:
        conts = db.query(Container).order_by(Container.id.desc()).limit(6).all()
        if not conts:
            return "📦 Abhi koi Container darj nahi hai."
        lines = ["📦 <b>Containers Status:</b>"]
        for c in conts:
            rep = get_container_report(db, c.container_no)
            sorted_kg = rep["total_sorted"] if rep else 0
            rec = rep["recovery"] if rep else 0
            tag = " [PURANA]" if c.is_archive else ""
            lines.append(f"• <b>{c.container_no}</b> ({c.status}){tag}: Sorted {sorted_kg:,.1f} / {c.invoice_nw:,.1f} KG ({rec:.1f}% Rec)")
        return "<br>".join(lines)

    if "low" in ql or "kam" in ql or "alert" in ql:
        lows = stock["low_stocks"]
        if not lows:
            return "✅ Sabhi main materials 500 KG se upar hain — koi Low Stock alert nahi hai!"
        lines = [f"⚠️ <b>Low Stock ({len(lows)} items < 500 KG):</b>"]
        for l in lows[:8]:
            lines.append(f"• <b>{l['item_name']}</b>: sirf {l['balance']:,.2f} KG bacha hai")
        return "<br>".join(lines)

    # Check if user asked about a specific material in stock (e.g. "Birch ka khata dikhao", "Berry kitna hai")
    for r in stock["all_rows"]:
        iname = r["item_name"].lower()
        first_word = iname.split()[0] if iname else ""
        if iname in ql or (len(first_word) >= 4 and first_word in ql):
            return (
                f"📒 <b>{r['item_name']}</b> ({r['material_category']}):<br>"
                f"• Total Aaya (In): <b>{r['total_in']:,.2f} KG</b> ({r['jambo_in']} Bag)<br>"
                f"• Total Gaya (Out): <b>{r['total_out']:,.2f} KG</b> ({r['jambo_out']} Bag)<br>"
                f"• <b>Net Balance: {r['balance']:,.2f} KG ({r['jambo_balance']} Jambo)</b><br>"
                f"<a href='/khata?item={r['item_name']}' style='color:#f472b6;font-weight:700;'>→ Poora Khata Kholo</a>"
            )

    # Optional conversational fallback via configured reader keys (never exposing provider name)
    prim_keys, sec_keys = _collect_keys(db)
    context_txt = (
        f"Company: PARAS OVERSEAS JHULASAN (Copper & Scrap Factory). "
        f"Total Main Live Stock: {stock['total_main_kg']} KG ({stock['total_main_jambo']} Jambo). "
        f"Items: " + ", ".join(f"{r['item_name']}={r['balance']}KG" for r in stock["all_rows"][:15]) + ". "
        "Reply briefly in polite Hinglish as Jyoti (factory manager assistant). "
        "STRICT RULE: Never mention any AI, model, Gemini, Groq, or company name. Never mention money/rupees, only KG and Jambo."
    )
    for key_id, api_key in prim_keys[:2]:
        try:
            resp = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}",
                json={
                    "contents": [{"parts": [{"text": f"{context_txt}\nUser Question: {q}"}]}],
                    "generationConfig": {"temperature": 0.3, "maxOutputTokens": 250},
                },
                timeout=12,
            )
            if resp.status_code == 200:
                ans = resp.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
                _mark_key_result(db, key_id, True)
                return ans.replace("\n", "<br>")
        except Exception:
            pass

    for key_id, sec_key in sec_keys[:1]:
        try:
            resp = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization": f"Bearer {sec_key}", "Content-Type": "application/json"},
                json={
                    "model": "llama-3.3-70b-versatile",
                    "messages": [
                        {"role": "system", "content": context_txt},
                        {"role": "user", "content": q},
                    ],
                    "max_tokens": 250,
                },
                timeout=12,
            )
            if resp.status_code == 200:
                ans = resp.json()["choices"][0]["message"]["content"].strip()
                _mark_key_result(db, key_id, True)
                return ans.replace("\n", "<br>")
        except Exception:
            pass

    return (
        f"Ji sir! Abhi factory me <b>{stock['total_main_kg']:,.2f} KG</b> ({stock['total_main_jambo']} Jambo) Main Stock hai. "
        f"Aap mujhse <b>'Live Stock'</b>, <b>'Birch Khata'</b>, <b>'Container Status'</b>, <b>'Furnace Loss'</b> ya <b>'Dispatch'</b> pooch sakte hain! 🩷"
    )
