import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.database import SessionLocal
from app.models import init_db
from app.security import get_current_actor
from app.routes import auth_admin, erp_home, modules

os.makedirs("uploads/media", exist_ok=True)
os.makedirs("uploads/dispatch", exist_ok=True)
os.makedirs("static", exist_ok=True)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="Paras Overseas Jhulasan — Copper & Scrap ERP",
    version="4.0.0",
    lifespan=lifespan,
)


@app.middleware("http")
async def view_only_and_cache_middleware(request: Request, call_next):
    # Global double-layer enforcement for Seth Ji View-Only Mode
    if request.method in ("POST", "PUT", "DELETE", "PATCH"):
        path = request.url.path
        allowed_post_paths = {"/login", "/api/jyoti"}
        if path not in allowed_post_paths:
            db = SessionLocal()
            try:
                actor = get_current_actor(request, db)
                if actor.get("is_view_only"):
                    if path.startswith("/api/"):
                        return JSONResponse(
                            {"success": False, "error": "👔 Seth Ji View-Only Mode Active — Koi badlav allowed nahi hai."},
                            status_code=403,
                        )
                    return RedirectResponse(
                        url="/seth?err=👔+View-Only+Mode+Active+(Seth+Ji)+—+Sirf+dekh+sakte+hain",
                        status_code=303,
                    )
            finally:
                db.close()

    response = await call_next(request)
    if not request.url.path.startswith(("/static", "/uploads")):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    return response


app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

app.include_router(auth_admin.router)
app.include_router(erp_home.router)
app.include_router(modules.router)


@app.get("/health")
async def health_check():
    return {"status": "ok", "system": "Paras Overseas Copper ERP", "version": "4.0.0"}


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False)
